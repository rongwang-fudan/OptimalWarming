% Author: Rong Wang // contact rongwang@fudan.edu.cn //
% Date: 2021.7.31
% Establishing the energy system by zone

function [ S ] = Abatementzone( FFlux, L, dpower, dcoef, LR, covidyear, iec, iec_cn, calrsav, deffs, switcher, econcn, cndata, abtcn, tempzone, tempdiff, iecone, technology_diffusion, negative_emissions, NETs )

global Egreen realtime S0 cou_iform EFco2 theta2

% cou_iform % 1: id for 222 countries; 2: 2 developing/ 1 developed; 3: region id; 4 OECD; 5 id for 112 countries; 6 pi temperature

% T = size(realtime,1);
T = 400;

% inertia of the adjustment of labor / investment allocation
inertia=2;

%Run the simulation
t=1;
covid=1;
yabt=abtcn(1,1);
fabt=abtcn(1,2);
alen=abtcn(1,3);
cn_num=size(cndata,1);
S=zeros(T,35,cn_num+1);
S(1,1:34,1)=S0(1,1:34);
S(1,35,1)=L(1);
S(1,1:23,2:(cn_num+1))=econcn(1,1:23,1:cn_num);
S(1,35,2:(cn_num+1))=cndata(1:cn_num,4*49-48+1); % Labor in 1971
ZCE61=zeros(5,2);
while realtime(t,1)<2301
    % using the simulation results before abatements
    if realtime(t,1)<2019
        econ1 = S0(t,1:23);
        clim1 = S0(t,24:34);
        t=t+1;
        S(t,1:34,1) = S0(t,1:34);
        S(t,35,1) = L(t);
        S(t,1:23,2:(cn_num+1)) = econcn(t,1:23,1:cn_num);
        S(t,4,2:(cn_num+1)) = S0(t,4); % MAC of zero-carbon energy 
        S(t,22,2:(cn_num+1)) = S0(t,22);
        S(t,23,2:(cn_num+1)) = S0(t,23);
        S(t,35,2:(cn_num+1)) = S(t-1,35,2:(cn_num+1))*L(t)/L(t-1); % growth in labor
        continue;
    end
    %
    if t<33
        rsav=calrsav(3);
    elseif t<38
        rsav=calrsav(4);
    else
        rsav=calrsav(5);
    end
    %Fraction of investment allocated to carbon-emission-free energy: S transition
    if floor(realtime(t+1,1))>=yabt
        Nabt=realtime(t+1,1)-yabt;
        fracinv=(Egreen(end,8)-fabt)*exp(-(Nabt^2)/2/alen/alen)+fabt;
    else
        fracinv=Egreen(min(45,t),8);
    end
    %Energy cost share (Omega) in the past 20 years
    omega=0; tt=0;
    for i=1:t
        if (realtime(t,1)-realtime(i,1))<20
            omega=omega+S(i,15,1)*realtime(i,2);
            tt=tt+realtime(i,2);
        end
    end
    omega = omega/tt;
    %Investment for the previous calender year
    investment=0; tt2=0;
    nextyear=floor(realtime(t+1,1)+realtime(t+1,2)/2);
    for i=1:t
        if nextyear==(floor(realtime(i,1)+realtime(i,2)/2)+1)
            investment = investment + rsav * S(i,7,1) * realtime(i,2);
            tt2 = tt2 + realtime(i,2);
        end
    end
    investment=investment/tt2;
    %Change of efficiencies in COVID-19
    if realtime(t,1)>covidyear && covid<=11 && realtime(t,1)<(covidyear+1)
        deff=[1+deffs(1,covid),1+deffs(2,covid),1+deffs(3,covid)];
        covid=covid+1;
    else
        deff=[1,1,1];
    end
    %Evolution of state from time t to time (t+1)
    econ2 = econdyn(t, L(t), econ1, fracinv, iec, omega, investment, LR, clim1(8), dpower, dcoef, inertia, deff, switcher);
    ZCE=zeros(5,2);
    for cn=1:cn_num
        cn_labor = S(t,35,cn+1);
        cn_econ0 = S(t,1:23,cn+1);        
        cn_omega = S(t,15,cn+1);
        cn_invest = rsav*S(t,7,cn+1);
        cn_yabt=abtcn(cn,1);
        if floor(realtime(t+1,1))>=cn_yabt
            cn_fabt=abtcn(cn,2);
            cn_alen=abtcn(cn,3);
            cn_Nabt=realtime(t+1,1)-cn_yabt;
            cn_fabt0=cndata(cn,5*49-48+45)/cndata(cn,2*49-48+45); % the penetration of ZC energy in 2015
            cn_fracinv=(cn_fabt0-cn_fabt)*exp(-(cn_Nabt^2)/2/cn_alen/cn_alen)+cn_fabt;
        else
            cn_fracinv=cndata(cn,5*49-48+min(45,t))/cndata(cn,2*49-48+min(45,t));
        end
        if tempdiff==1
            if cn>1
                cnzone=cou_iform(cndata(cn,1),7);
                cn_temp=cou_iform(cndata(cn,1),6)-13+clim1(8)*tempzone(cnzone,1)+tempzone(cnzone,2);
            else
                cn_temp=clim1(8);
            end
        else
            cn_temp=clim1(8);
        end
        if iecone==1
            iec_cnadopt=iec_cn(:,:,cn);
        else
            iec_cnadopt=iec;
        end
        LRcn=0;
        S(t+1,1:23,cn+1) = econdyn(t, cn_labor, cn_econ0, cn_fracinv, iec_cnadopt, cn_omega, cn_invest, LRcn, abs(cn_temp), dpower, dcoef, inertia, deff, switcher);
        S(t+1,31,cn+1) = cn_temp; % Atmospheric temperature difference to 13 C
        S(t+1,35,cn+1) = S(t,35,cn+1)*L(t+1)/L(t); % labor
        if cn>1
            zz=cou_iform(cndata(cn,1),4);
            ZCE(zz,1) = ZCE(zz,1) + S(t,21,cn+1); % energy PJ
            ZCE(zz,2) = ZCE(zz,2) + S(t+1,21,cn+1); % energy PJ
            ZCE(5,1) = ZCE(5,1) + S(t,21,cn+1); % energy PJ
            ZCE(5,2) = ZCE(5,2) + S(t+1,21,cn+1); % energy PJ
        end
    end
    % re-calculate the carbon price of 100% emission abatement by considering learning by doing and global cooperation
    ZC0 = 72000;
    for zz=1:5
        ZCE(zz,1) = max(ZC0,ZCE(zz,1)); % energy PJ
        ZCE(zz,2) = max(ZCE(zz,1),ZCE(zz,2)); % energy PJ
    end
    if ZCE61(5,1)==0
        ZCE61=ZCE; % initializing
    end
    for cn=1:cn_num
        if cn>1
            zz=cou_iform(cndata(cn,1),4);
        else
            zz=5;
        end
        % MAC after learning (without considering the effect of increasing energy demand)
        if technology_diffusion==1
            % 1 taking the globe as a whole
            S(t+1,4,cn+1) = econ2(4);
        elseif technology_diffusion==2
            % 2 without technology diffusion between countries
            ZCEnergy0 = max(ZC0,S(t,21,cn+1)-S(61,21,cn+1)+S(61,21,1));
            ZCEnergy1 = max(ZCEnergy0,S(t+1,21,cn+1)-S(61,21,cn+1)+S(61,21,1));
            LRcn = log2(1-min(LR*2,max(LR,LR+log(ZCEnergy0/3600/50)/log(4)*0.2)));
            S(t+1,4,cn+1) = S(t,4,cn+1)*(max(1+0.01*realtime(t,2),ZCEnergy1/ZCEnergy0))^LRcn; 
        elseif technology_diffusion==3
            % 3 global technology diffusion
            LRcn = log2(1-min(LR*2,max(LR,LR+log(ZCE(5,1)/3600/50)/log(4)*0.2)));
            S(t+1,4,cn+1) = S(t,4,cn+1)*(max(1+0.01*realtime(t,2),ZCE(5,2)/ZCE(5,1)))^LRcn;
        elseif technology_diffusion==4
            % 4 regional technology diffusion
            ZCEnergy0 = max(ZC0,ZCE(zz,1)-ZCE61(zz,1)+ZCE61(5,1));
            ZCEnergy1 = max(ZCEnergy0,ZCE(zz,2)-ZCE61(zz,1)+ZCE61(5,1));
            LRcn = log2(1-min(LR*2,max(LR,LR+log(ZCEnergy0/3600/50)/log(4)*0.2)));
            S(t+1,4,cn+1) = S(t,4,cn+1)*(max(1+0.01*realtime(t,2),ZCEnergy1/ZCEnergy0))^LRcn; 
        end
        S(t+1,19,cn+1) = S(t+1,4,cn+1) * S(t+1,18,cn+1)^(theta2-1); % carbon price
    end
    % 1 without negative emissions (default); 2 with negative emissions
    if negative_emissions==2 && clim1(8)>1
        for cn=1:cn_num
            S(t+1,20,cn+1) = EFco2(min(45,t)) * S(t+1,12,cn+1) * (1-Egreen(min(45,t+1),8)) * (1-S(t+1,18,cn+1)*(1+NETs) ); % CO2 emission
            S(t+1,18,cn+1) = S(t+1,18,cn+1) * (1 + NETs); % Fraction of emission abatement
            S(t+1,19,cn+1) = S(t+1,4,cn+1) * S(t+1,18,cn+1)^(theta2-1); % carbon price
        end
    end
    %
    emico2=sum(S(t+1,20,3:(cn_num+1)),3); % CO2 emission
    if switcher(2)==0
        clim2=climdynexo(t, clim1, FFlux, emico2);
    else
        clim2=climdyn(t, clim1, FFlux, emico2);
    end
    
    S(t+1,1:23,1)=econ2(1,1:23);
    S(t+1,24:34,1)=clim2(1,1:11);
    S(t+1,35,1)=L(t+1); % labor
    %
    t=t+1;
    econ1=econ2;
    clim1=clim2;
end

for cn=1:(cn_num+1)
    S(:,1,cn) = S(:,1,cn) * 3600; % EUE $/KJ -> $/kWh
    S(:,2,cn) = S(:,2,cn) / 3600; % EPE PJ/(t$)^0.3 / (billion cap)^0.7 -> PWh/(t$)^0.3 / (billion cap)^0.7
    S(:,12,cn) = S(:,12,cn) / 3600; % energy PJ -> PWh
    S(:,21,cn) = S(:,21,cn) / 3600; % cumulative green energy PJ -> PWh
end

end
