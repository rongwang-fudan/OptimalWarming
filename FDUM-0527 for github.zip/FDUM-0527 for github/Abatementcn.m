% Author: Rong Wang // contact rongwang@fudan.edu.cn //
% Date: 2021.7.31
% Establishing the energy system by zone

function [ S ] = Abatementcn( FFlux, L, dpower, dcoef, LR, covidyear, iec, iec_cn, calrsav, deffs, switcher, econcn, cndata, abtcn, tempdiff )

global Egreen realtime S0 cou_iform

% cou_iform % 1: id for 222 countries; 2: 2 developing/ 1 developed; 3: region id; 4 OECD; 5 id for 112 countries; 6 pi temperature

T = size(realtime,1);

% inertia of the adjustment of labor / investment allocation
inertia=2;

%Run the simulation
t=1;
covid=1;
yabt=abtcn(1,1);
fabt=abtcn(1,2);
alen=abtcn(1,3);
cn_num=size(cndata,1);
S=zeros(T,35,cn_num+1);
S(1,1:34,1)=S0(1,1:34);
S(1,35,1)=L(1);
S(1,1:23,2:(cn_num+1))=econcn(1,1:23,1:cn_num);
S(1,35,2:(cn_num+1))=cndata(1:cn_num,4*49-48+1); % Labor in 1971
while realtime(t,1)<2301
    % using the simulation results before abatements
    if realtime(t,1)<2019
        econ1 = S0(t,1:23);
        clim1 = S0(t,24:34);
        t=t+1;
        S(t,1:34,1) = S0(t,1:34);
        S(t,35,1) = L(t);
        S(t,1:23,2:(cn_num+1)) = econcn(t,1:23,1:cn_num);
        S(t,4,2:(cn_num+1))  = S0(t,4); % MAC of zero-carbon energy 
        S(t,22,2:(cn_num+1))  = S0(t,22);
        S(t,23,2:(cn_num+1))  = S0(t,23);
        S(t,35,2:(cn_num+1)) = S(t-1,35,2:(cn_num+1))*L(t)/L(t-1); % growth in labor
        continue;
    end
    %
    if t<33
        rsav=calrsav(3);
    elseif t<38
        rsav=calrsav(4);
    else
        rsav=calrsav(5);
    end
    %Fraction of investment allocated to carbon-emission-free energy: S transition
    if floor(realtime(t+1,1))>=yabt
        Nabt=realtime(t+1,1)-yabt;
        fracinv=(Egreen(end,8)-fabt)*exp(-(Nabt^2)/2/alen/alen)+fabt;
    else
        fracinv=Egreen(min(45,t),8);
    end
    %Energy cost share (Omega) in the past 20 years
    omega=0; tt=0;
    for i=1:t
        if (realtime(t,1)-realtime(i,1))<20
            omega=omega+S(i,15,1)*realtime(i,2);
            tt=tt+realtime(i,2);
        end
    end
    omega = omega/tt;
    %Investment for the previous calender year
    investment=0; tt2=0;
    nextyear=floor(realtime(t+1,1)+realtime(t+1,2)/2);
    for i=1:t
        if nextyear==(floor(realtime(i,1)+realtime(i,2)/2)+1)
            investment = investment + rsav * S(i,7,1) * realtime(i,2);
            tt2 = tt2 + realtime(i,2);
        end
    end
    investment=investment/tt2;
    %Change of efficiencies in COVID-19
    if realtime(t,1)>covidyear && covid<=11 && realtime(t,1)<(covidyear+1)
        deff=[1+deffs(1,covid),1+deffs(2,covid),1+deffs(3,covid)];
        covid=covid+1;
    else
        deff=[1,1,1];
    end
    %Evolution of state from time t to time (t+1)
    econ2 = econdyn(t, L(t), econ1, fracinv, iec, omega, investment, LR, clim1(8), dpower, dcoef, inertia, deff, switcher);    
    for cn=1:cn_num
        cn_labor = S(t,35,cn+1);
        cn_econ0 = S(t,1:23,cn+1);        
        cn_omega = S(t,15,cn+1);
        cn_invest = rsav*S(t,7,cn+1);
        cn_yabt=abtcn(cn,1);
        if floor(realtime(t+1,1))>=cn_yabt
            cn_fabt=abtcn(cn,2);
            cn_alen=abtcn(cn,3);
            cn_Nabt=realtime(t+1,1)-cn_yabt;
            cn_fabt0=cndata(cn,5*49-48+45)/cndata(cn,2*49-48+45); % the penetration of ZC energy in 2015
            cn_fracinv=(cn_fabt0-cn_fabt)*exp(-(cn_Nabt^2)/2/cn_alen/cn_alen)+cn_fabt;
        else
            cn_fracinv=cndata(cn,5*49-48+min(45,t))/cndata(cn,2*49-48+min(45,t));
        end
        if tempdiff==1
            if cn>1
                cn_temp=abs(cou_iform(cndata(cn,1),6)-13+clim1(8));
            else
                cn_temp=clim1(8);
            end
        else
            cn_temp=clim1(8);
        end
        S(t+1,1:23,cn+1)=econdyn(t, cn_labor, cn_econ0, cn_fracinv, iec_cn(:,:,cn), cn_omega, cn_invest, LR, cn_temp, dpower, dcoef, inertia, deff, switcher);
        S(t+1,4,cn+1)=econ2(4);        
        S(t+1,19,cn+1)=S(t+1,4,cn+1)*S(t+1,18,cn+1)^(theta2-1); % carbon price        
        S(t+1,35,cn+1)=S(t,35,cn+1)*L(t+1)/L(t); % labor
    end
    emico2=sum(S(t+1,20,3:(cn_num+1)),3); % CO2 emission
    clim2=climdyn(t, clim1, FFlux, emico2);
    t=t+1;
    econ1=econ2;
    clim1=clim2;
    S(t,1:23,1)=econ2(1,1:23);
    S(t,24:34,1)=clim2(1,1:11);
    S(t,35,1)=L(t); % labor
%     Debugging by Rong Wang
%     AA=zeros(50,cn_num+1);
%     for si=1:50
%         for sj=1:(cn_num+1)
%             AA(si,sj)=S(si,3,sj);
%         end
%     end
%     AA=zeros(cn_num,1); AA(1:cn_num,1)=S(50,12,2:(cn_num+1))./S(49,12,2:(cn_num+1));
%     id=12; plot(S(1:50,id,1)); hold on; plot(S(1:50,id,108));
%     id=20; t=49; sum(S(t,id,3:(cn_num+1)),3)/S(t,id,2)
end

for cn=1:(cn_num+1)
    S(:,1,cn) = S(:,1,cn) * 3600; % EUE $/KJ -> $/kWh
    S(:,2,cn) = S(:,2,cn) / 3600; % EPE PJ/(t$)^0.3 / (billion cap)^0.7 -> PWh/(t$)^0.3 / (billion cap)^0.7
    S(:,12,cn) = S(:,12,cn) / 3600; % energy PJ -> PWh
    S(:,21,cn) = S(:,21,cn) / 3600; % cumulative green energy PJ -> PWh
end

end
