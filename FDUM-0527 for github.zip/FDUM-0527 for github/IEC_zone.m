% Author: Rong Wang // contact rongwang@fudan.edu.cn //
% Date: 2021.6.18

function [iec_cn, slopecn ] = IEC_zone( cndata )

% Economic variables cndata(KEYL)

% Economic variables econcn=zeros(49,23,i2+1)
% 1 EUE; 2 EPE; 3 ENE; 4 backstop price $/tCO2
% 5 abatement cost as a percentage of GDP; 6 climate damage as a percentage of GDP; 7 net output
% 8 fraction of labor allocation to energy; 9 fraction of investment allocation to energy
% 10 total capital (t$); 11 energy capital (t$); 12 energy (PJ); 13 output (t$); 14 energy price $/kWh; 15 omega
% 16 fraction of energy investment allocated to zero-carbon energy
% 17 energy capital carbon-emission-free (t$);
% 18 fraction to abate CO2 emission; 19 carbon price $/tCO2; 20 CO2 emissions Gt CO2; 21 green energy PJ; 22 invest change, 23 labor change

global alpha elas inputs cou_iform
%   alpha:  elasticity of output to capital
%   elas:   elasticity of substitution between energy and non-energy in output

cn_num=size(cndata,1);
omegas=(-1.52:0.01:-0.82); sn=size(omegas,2);
omegas2=(-0.071:0.001:-0.013); sn2=size(omegas2,2);

% 1. Eastern and Southern Africa; 2. Northern Africa; 3. Western and Central Africa; 4. East Asia; 5. South and South-east Asia; 6. Western and Central Asia;
% 7. Europe; 8. Caribbean; 9. Central America; 10. North America; 11. Oceania; 12. South America
zonenum=8;
z8data=zeros(zonenum,49,4); % 1 Globe; 2 Africa, 3 East Asia; 4 South/Southeast Asia; 5 Middle East; 6 Europe; 7 North America; 8 Oceania
z8id=[2 2 2 3 4 5 6 0 0 7 8 0];
for i=1:49
    for k=1:4
        z8data(1,i,k)=cndata(1,(k*49-48+i)); % Globe
        for cn=2:cn_num
            z8=z8id(1,cou_iform(cndata(cn,1),3));
            if z8>=2 && z8<=zonenum
                z8data(z8,i,k)=z8data(z8,i,k)+cndata(cn,(k*49-48+i));
            end
        end
    end
end

iec_cn=zeros(6,sn,cn_num);
iec_zone=zeros(6,sn,zonenum);
xy_iec_zone=zeros(30,9,zonenum);
slopecn=zeros(zonenum,9);

for cn=1:zonenum

iec_zone0=zeros(6,sn);
xy_iec_zone0=zeros(30,9);
lra=zeros(30,7);
for i=1:30
    x=[(1970+i):(1989+i)];
    x15=[(1970+i):min(1989+i,2015)];
    i15=min((i+19),45);
    y=inputs(i:i15,5); [sR,lr_pe0,bb0] = regression(x15,log(y')); % energy price
    y=z8data(cn,i:(i+19),2)./z8data(cn,i:(i+19),4); [sR,lr_e0,bb0] = regression(x,log(y)); % e=E/L
    y=z8data(cn,i:(i+19),3)./z8data(cn,i:(i+19),4); [sR,lr_y0,bb0] = regression(x,log(y)); % y=Y/L
    y=z8data(cn,i:(i+19),1)./z8data(cn,i:(i+19),4); [sR,lr_k0,bb0] = regression(x,log(y)); % k=K/L    
    y=inputs(i:i15,6) .* (z8data(cn,i:i15,2)./z8data(cn,i:i15,3)) ./ (inputs(i:i15,1).*3600./inputs(i:i15,3)); % omega    
    avef0=mean(y,1); startf0=y(1);
    lr_se0 = lr_pe0 + lr_e0 - lr_y0;
    lr_B = lr_e0 - alpha*lr_k0;
    lr_A = lr_y0 - alpha*lr_k0;
    lr_taue0 = elas/(elas-1)*lr_se0 - lr_e0 + lr_y0;
    lr_we0 = lr_B - lr_se0;
    lr_b0 = (lr_A - avef0*(lr_we0 + lr_taue0))/(1-avef0);
    lra(i,1) = startf0;
    lra(i,2) = lr_taue0;
    lra(i,3) = lr_we0;
    lra(i,4) = max(0.0001,lr_b0);
    lra(i,5) = 0; % damage of climate change
    lra(i,6) = lra(i,1);
    lra(i,7) = 1-lra(i,1);
    lra(i,8) = lr_se0;
end
xy_iec_zone0(:,1)=lra(:,2); % eue rate
xy_iec_zone0(:,2)=lra(:,3); % epe rate
xy_iec_zone0(:,3)=lra(:,4); % ene rate
xy_iec_zone0(:,4)=lra(:,6); % omega
xy_iec_zone0(:,5)=lra(:,7); % 1 - omega
xy_iec_zone0(:,9)=lra(:,8); % omega rate

% EUE
x=log10(lra(:,6)); y=lra(:,2);
a=polyfit(x,y,1);
iec_zone0(1,1:sn)=polyval(a,omegas);
xy_iec_zone0(:,6)=polyval(a,x);
[R,P] = corrcoef(x,y);
[b2,bint2,r2,rint2,stats2]=regress(y,[ones(size(x,1),1) x]);
slopecn(cn,1) = b2(2);
slopecn(cn,2) = mean(y,1);
slopecn(cn,3) = (bint2(2,2)-bint2(2,1))/1.96/2/b2(2);

% EPE
y=lra(:,3);
a=polyfit(x,y,1);
iec_zone0(2,:)=polyval(a,omegas);
xy_iec_zone0(:,7)=polyval(a,x);
[R,P] = corrcoef(x,y);
[b2,bint2,r2,rint2,stats2]=regress(y,[ones(size(x,1),1) x]);
slopecn(cn,4) = b2(2);
slopecn(cn,5) = mean(y,1);
slopecn(cn,6) = (bint2(2,2)-bint2(2,1))/1.96/2/b2(2);

% ENE - 1-omega
idxene=find(lra(:,4)>=0.0015); % destroyed economy
x=log10(lra(idxene,7));
y=lra(idxene,4);
a=polyfit(x,y,1);
iec_zone0(4,1:sn2)=polyval(a,omegas2);
[b2,bint2,r2,rint2,stats2]=regress(y,[ones(size(x,1),1) x]);
slopecn(cn,7) = b2(2);
slopecn(cn,8) = mean(y,1);
slopecn(cn,9) = (bint2(2,2)-bint2(2,1))/1.96/2/b2(2);

% else
% idxene=find(lra(:,4)>=0.0015); % destroyed economy
% eney=lra(idxene,4);
% enex=lra(idxene,7);
% 
% [B, IX] = sort(enex, 1);
% 
% idxene1=find(enex>=B(1));
% eney1=eney(idxene1,1);
% enex1=log10(enex(idxene1,1));
% idxene2=find(enex<=B(7));
% eney2=eney(idxene2,1);
% enex2=log10(enex(idxene2,1));
% 
% a=polyfit(enex1,eney1,1);
% a1=polyval(a,omegas2);
% a=polyfit(enex2,eney2,1);
% a2=polyval(a,omegas2);
% iec_zone0(4,1:sn2)=max(a1,a2);
% 
% end

for i=1:sn2
    iec_zone0(4,i)=max(0.001,iec_zone0(4,i));
end

iec_zone0(5,:)=omegas;
iec_zone0(6,1:sn2)=omegas2;

iec_zone(:,:,cn)=iec_zone0;
xy_iec_zone(:,:,cn)=xy_iec_zone0;

end

%     % EUE rates as a function of log10(Omega)
%     for cn=1:zonenum
%         subplot(4,2,cn);     
%         x=log10(xy_iec_zone(:,4,cn)); y=xy_iec_zone(:,1,cn); a=polyfit(x,y,1); 
%         x2=[-1.7:0.1:-0.8]; y2=polyval(a,x2);
%         i2=size(x2,2); y3=zeros(2,i2);
%         for i=1:i2
%             y3(1,i) = slopecn(cn,2) + (y2(1,i)-slopecn(cn,2)) * (1-slopecn(cn,3)*1.96);
%             y3(2,i) = slopecn(cn,2) + (y2(1,i)-slopecn(cn,2)) * (1+slopecn(cn,3)*1.96);
%         end
%         plot(x,y,'o','MarkerEdgeColor',[0 0 1],'MarkerFaceColor','none','MarkerSize',3); hold on;        
%         plot(x2,y2,'LineStyle','--','LineWidth',2,'Color',[0.8 0 0]); hold on;        
%         plot(x2,y3(1,:),'LineStyle','--','LineWidth',1,'Color',[1 0.7 0.7]); hold on;        
%         plot(x2,y3(2,:),'LineStyle','--','LineWidth',1,'Color',[1 0.7 0.7]); hold on;
% %         plot(iec_zone(5,1:71,cn),iec_zone(1,1:71,cn),'LineStyle','-','LineWidth',0.1,'Color',[0.7 0.7 0.7]); hold on;
%         axis([-1.7 -0.8 -0.08 0.08]);
%     end
%     
%     % EPE rates as a function of log10(Omega)
%     for cn=1:zonenum
%         subplot(4,2,cn);     
%         x=log10(xy_iec_zone(:,4,cn)); y=xy_iec_zone(:,2,cn); a=polyfit(x,y,1); 
%         x2=[-1.7:0.1:-0.8]; y2=polyval(a,x2);
%         i2=size(x2,2); y3=zeros(2,i2);
%         for i=1:i2
%             y3(1,i) = slopecn(cn,5) + (y2(1,i)-slopecn(cn,5)) * (1-slopecn(cn,6)*1.96);
%             y3(2,i) = slopecn(cn,5) + (y2(1,i)-slopecn(cn,5)) * (1+slopecn(cn,6)*1.96);
%         end
%         plot(x,y,'o','MarkerEdgeColor',[0 0 1],'MarkerFaceColor','none','MarkerSize',3); hold on;        
%         plot(x2,y2,'LineStyle','--','LineWidth',2,'Color',[0.8 0 0]); hold on;        
%         plot(x2,y3(1,:),'LineStyle','--','LineWidth',1,'Color',[1 0.7 0.7]); hold on;        
%         plot(x2,y3(2,:),'LineStyle','--','LineWidth',1,'Color',[1 0.7 0.7]); hold on;
%         axis([-1.7 -0.8 -0.08 0.08]);
%     end
%     
%     % ENE rates as a function of log10(1-Omega)
%     for cn=1:zonenum
%         subplot(4,2,cn);
%         idxene=find(xy_iec_zone(:,3,cn)>=0.0015); % destroyed economy
%         x=log10(xy_iec_zone(idxene,5,cn)); y=xy_iec_zone(idxene,3,cn); a=polyfit(x,y,1); 
%         x2=[-0.08:0.01:0]; y2=polyval(a,x2);
%         i2=size(x2,2); y3=zeros(2,i2);
%         for i=1:i2
%             y3(1,i) = slopecn(cn,8) + (y2(1,i)-slopecn(cn,8)) * (1-slopecn(cn,9)*1.96);
%             y3(2,i) = slopecn(cn,8) + (y2(1,i)-slopecn(cn,8)) * (1+slopecn(cn,9)*1.96);
%         end
%         plot(x,y,'o','MarkerEdgeColor',[0 0 1],'MarkerFaceColor','none','MarkerSize',3); hold on;        
%         plot(x2,y2,'LineStyle','--','LineWidth',2,'Color',[0.8 0 0]); hold on;        
%         plot(x2,y3(1,:),'LineStyle','--','LineWidth',1,'Color',[1 0.7 0.7]); hold on;        
%         plot(x2,y3(2,:),'LineStyle','--','LineWidth',1,'Color',[1 0.7 0.7]); hold on;
%         axis([-0.08 0 0 0.04]);
%     end
% end

% save('slopecn.dat','slopecn');
% save('xy_iec_zone.dat','xy_iec_zone');

for i=1:sn
    for k=1:6
        iec_cn(k,i,1)=iec_zone(k,i,1); % Globe
        for cn=2:cn_num
            z8=z8id(1,cou_iform(cndata(cn,1),3));
            if z8>=2 && z8<=zonenum
                iec_cn(k,i,cn)=iec_zone(k,i,z8);
            end
        end
    end
end

end

%Regression coefficient
% k_EUE = 0.1357; % coefficient for EUE (slope to energy cost share)
% b_EUE = 0.1717; % coefficient for EUE (offset)
% k_EPE = 0.1985; % coefficient for EPE (slope to energy cost share)
% b_EPE = 0.2256; % coefficient for EPE (offset)
% k_ENE = -0.013; % coefficient for ENE (slope to energy cost share)
% b_ENE = - k_ENE * log10(0.1) + ENErate(Ts1,1); % coefficient for ENE (offset)


