% Author: Rong Wang // contact rongwang@fudan.edu.cn //
% Date: 2021.7.31
% Establishing the energy system by zone

function [ output_cns, output_nations, util_cn, duyy ] = ModelCN( FFlux, L, iec, xy_iec, calrsav, output_cap, deffs, dpo, dcoef, LR, covidyear, tempdiff )

global realtime elas carbonbudget20 Eland EFco2 Fex cou_iform cndata

unc=[1	1	1.028301887	0.9853	0.9412	1.068190855	1.060618557	1	0.959279794	0.907512099	1	1	1	1	1.147	1	1	1];

%Coefficient in the damage function
dcoef = dcoef * unc(1);
%Elasticity of substitution (avoid a zero-like elas)
elas = elas * unc(15);
%Learning rate on the cost curve
LR = LR * unc(18);

%Equilibrium sensitivity of climate
FFlux(1) = FFlux(1) * unc(2);
%Time inertia of climate system to reach equilibirum (year)
FFlux(2) = FFlux(2) * unc(3);
%air to land biosphere GtC/yr
FFlux(4) = FFlux(4) * unc(6);
%air to surface ocean GtC/yr
FFlux(5) = FFlux(5) * unc(7);
%land biosphere to soil GtC/yr
FFlux(6) = FFlux(6) * unc(8);
%surface soil to deep soil GtC/yr
FFlux(7) = FFlux(7) / unc(9);
%surface ocean to deep ocean GtC/yr
FFlux(8) = FFlux(8) / unc(10);

%CO2 emission factors for fossil fuel only tCO2 / MJ
EFco2 = EFco2 * unc(4);
carbonbudget20(:,2) = carbonbudget20(:,2) * unc(4);
%CO2 emissions from land use change
Eland = Eland * unc(5);
%Radiative forcing by 1 CH4, 2 N2O, 3 CFCs, 4 aerosol
for i=1:4
    Fex(:,i) = Fex(:,i) * unc(i+10);
end

% switcher for  C1	C2	S1	S2	S3	S4	S5	T1	T2	T3	T4
switcher = ones(1,10);

%Input of data by country: cndata(1+119,1+49*4) KEYL+Et+Ez
[econcn] = countrydata( output_cap, dpo, dcoef, cndata, tempdiff );

%Rates of induced efficiency changes by country
plot_iec_cn = 0; % plot iec by country
[iec_cn, slopecn] = IEC_cn( cndata, iec, xy_iec, plot_iec_cn );

% abatement setting by country
cn_num=size(cndata,1);
abtcn=zeros(cn_num,3);
abtcn(1:cn_num,1)=2025;
abtcn(1:cn_num,2)=1;
abtcn(1:cn_num,3)=10;
ccid=zeros(222,1);
for i=2:cn_num
    ccid(cndata(i,1),1)=i-1;
end

abtcn1=abtcn;
% Abatement by country - mitigation in 2025
S = Abatementcn( FFlux, L, dpo, dcoef, LR, covidyear, iec, iec_cn, calrsav, deffs, switcher, econcn, cndata, abtcn1, tempdiff ); % zeros(T,35,cn_num+1)    
% Economic variables
% 1 EUE; 2 EPE; 3 ENE; 4 backstop price $/tCO2
% 5 abatement cost as a percentage of GDP; 6 climate damage as a percentage of GDP; 7 net output
% 8 fraction of labor allocation to energy; 9 fraction of investment allocation to energy
% 10 total capital (t$); 11 energy capital (t$); 12 energy (PJ); 13 output (t$); 14 energy price $/kWh; 15 omega
% 16 fraction of energy investment allocated to zero-carbon energy
% 17 energy capital carbon-emission-free (t$);
% 18 fraction to abate CO2 emission; 19 carbon price $/tCO2; 20 CO2 emissions Gt CO2; 21 green energy PJ; 22 invest change, 23 labor change
output_nations=zeros(396,cn_num+1);
for cn=1:(cn_num+1)
    output_nations(1:396,cn)=S(1:396,7,cn);
end

output_cns=zeros(396,23*3);
output_cns(1:396,1:21)=S(1:396,1:21,1);
output_cns(1:396,22)=S(1:396,35,1);
output_cns(1:396,23)=S(1:396,31,1);
for i=1:21
    if i==7 || i==10 || i==11 || i==12 || i==13 || i==17 || i==20 || i==21
        output_cns(1:396,i+23)=sum(S(1:396,i,3:(cn_num+1)),3);
    else
        output_cns(1:396,i+23)=mean(S(1:396,i,3:(cn_num+1)),3);
    end
end
output_cns(1:396,45)=sum(S(1:396,35,3:(cn_num+1)),3);
output_cns(1:396,46)=S(1:396,31,1);
% Mitigation in 2025 but taking 200 years
abtcn1(1:cn_num,3)=200;
S = Abatementcn( FFlux, L, dpo, dcoef, LR, covidyear, iec, iec_cn, calrsav, deffs, switcher, econcn, cndata, abtcn1, tempdiff ); % zeros(T,35,cn_num)
for i=1:21
    if i==7 || i==10 || i==11 || i==12 || i==13 || i==17 || i==20 || i==21
        output_cns(1:396,i+46)=sum(S(1:396,i,3:(cn_num+1)),3);
    else
        output_cns(1:396,i+46)=mean(S(1:396,i,3:(cn_num+1)),3);
    end
end
output_cns(1:396,68)=sum(S(1:396,35,3:(cn_num+1)),3);
output_cns(1:396,69)=S(1:396,31,1);

%Abatement by country
util_cn=zeros(cn_num+1+14,14,50);
elasmu=1.45; % elasticity of marginal utility of consumption
for s=1:14
    abtcn(1:cn_num,1)=2020+s*5;
    S = Abatementcn( FFlux, L, dpo, dcoef, LR, covidyear, iec, iec_cn, calrsav, deffs, switcher, econcn, cndata, abtcn, tempdiff ); % zeros(T,35,cn_num)
    S2 = zeros(396,14);
    S3 = zeros(396,14);
    for cn=1:(cn_num+1)
        U0 = ((1-calrsav(5)).* S(45,7,cn)/S(45,35,cn)*1000)^(1-elasmu)/(1-elasmu); % utility in 2015
        for j=121:396 % starting from 2025
            for r=1:50
                Us = (((1-calrsav(5)).* S(j,7,cn)./S(j,35,cn)*1000)^(1-elasmu)/(1-elasmu)-U0)*L(j)/1000; % utility of action in 2025, 2030, 2035 ...
                util_cn(cn,s,r) = util_cn(cn,s,r) + Us * (1-r*0.001)^(realtime(j,1)-2020);  % Sum of NPV of utility
            end
        end
        % aggregate for 10 regions + 4 countries
        if cn>2
            S2(1:396,1)=S2(1:396,1)+S(1:396,7,cn);
            S3(1:396,1)=S3(1:396,1)+S(1:396,35,cn);
            cn2=cndata(cn-1,1);
            regionid=0;
            if cn2==37 || cn2==212
                regionid=2;
            elseif cou_iform(cn2,3)==7
                regionid=3;
            elseif cou_iform(cn2,3)==4
                regionid=4;
            elseif cou_iform(cn2,3)==5
                regionid=5;
            elseif cou_iform(cn2,3)==11
                regionid=6;
            elseif cou_iform(cn2,3)==6
                regionid=7;
            elseif cou_iform(cn2,3)<=3
                regionid=8;
            elseif cou_iform(cn2,3)>=8
                regionid=9;                
            end
            if regionid>=2 && regionid<=9
                S2(1:396,regionid)=S2(1:396,regionid)+S(1:396,7,cn);
                S3(1:396,regionid)=S3(1:396,regionid)+S(1:396,35,cn);
            end
            % typical countries
            cnid=0;
            if cn2==43
                cnid=10;
            elseif cn2==212
                cnid=11;
            elseif cn2==75
                cnid=12;
            elseif cn2==91
                cnid=13;
            elseif cn2==28
                cnid=14;
            end
            if cnid>=10 && cnid<=14
                S2(1:396,cnid)=S(1:396,7,cn);
                S3(1:396,cnid)=S(1:396,35,cn);
            end
        end
    end
    for cn=1:14
        U0 = ((1-calrsav(5)).* S2(45,cn)/S3(45,cn)*1000)^(1-elasmu)/(1-elasmu); % utility in 2015
        for j=121:396 % starting from 2025
            for r=1:50
                Us = (((1-calrsav(5)).* S2(j,cn)/S3(j,cn)*1000)^(1-elasmu)/(1-elasmu)-U0)*L(j)/1000; % utility of action in 2025, 2030, 2035 ...
                util_cn(cn+cn_num+1,s,r) = util_cn(cn+cn_num+1,s,r) + Us * (1-r*0.001)^(realtime(j,1)-2020);  % Sum of NPV of utility
            end
        end
    end
end

t=[5:5:25];
duds_cn=zeros(cn_num+15,10,50);
for cn=1:(cn_num+15)
    for r=1:50
        for s=1:10
            A=zeros(1,5);
            A(1:5)=util_cn(cn,s:(s+4),r);
            [rs,ms,bs] = regression(t,A);
            duds_cn(cn,s,r)=ms/(1-r*0.001)^(s*5); % discounting to the mitigation year
        end
    end
end

if tempdiff==0
    save('..\output\util_cn_notempdiff1229.dat','util_cn');
    save('..\output\duds_cn_notempdiff1229.dat','duds_cn');
else
    save('..\output\util_cn1229.dat','util_cn');
    save('..\output\duds_cn1229.dat','duds_cn');
end

% save('..\output\econcn134.dat','econcn');

duyy = zeros(14,12);
deltaU = 2.11;
duds_cn = duds_cn./deltaU;
for i=1:14
    duyy(i,1:10) = duds_cn(cn_num+1+i,1:10,15); % du/ds by year
    duyy(i,11) = mean(duds_cn(cn_num+1+i,1:3,15),2); % du/ds in 2035-2045
    duyy(i,12) = mean(duds_cn(cn_num+1+i,5:7,15),2); % du/ds in 2055-2065
end

end
