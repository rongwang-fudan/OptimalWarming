% Author: Rong Wang // contact rongwang@fudan.edu.cn //
% Date: 2021.12.20
tic
clear;

load('files/cndata134.dat','-mat');
cndata=cndata2; clear cndata2;
load('files/cou_iform.dat','-mat'); % 1: id for 222 countries; 2: 2 developing/ 1 developed; 3: 12 region id; 4 OECD; 5 id for 112 countries; 6 pi temperature
cou_iform=cou_iform2; clear cou_iform2;
load('files/country_ID.dat','-mat');   
cn_num=size(cndata,1);

effs=2; % 1 accounting for the impact of climate change on efficiencies (default); 2 not
Tech=3; % 1 gloabl rate (default); 2 technology by country alone; 3 global technology diffusion; 4 regional technology diffusion
Ymit=2025; % time needed in the transition of investment
Lmit=5; % time needed in the transition of investment
Seq=2; % sequence of entering the cooperation mechanism: 1 emission 2025-2125; 2 GDP per capita; 3 willingness of payment

% 1 globe; 2 globe; 3-136 by country; 137-140 OCED/REF/ASIA/ALM; 141 World
Nnet=31;
idr1=0.036; % low discounting by Stern2007
idr2=0.048; % real rate of return on equity (page 13 of The Rate of Return on Everything, 1870 – 2015 by Jorda 2019
elasmu=1.45; % elasticity of marginal utility of consumption
elasmu2=1-elasmu;

load('../cooperation/disc.dat','-mat');


filename2=strcat('../cooperation/climate_economy',num2str(effs),'tech',num2str(Tech),'_NET2_SEQ',num2str(Seq),'_Single1_transtime',num2str(Ymit),'_translen',num2str(Lmit),'yr-');

load(strcat(filename2,'S_Bau.dat'),'-mat');
load(strcat(filename2,'output_gt.dat'),'-mat');
load(strcat(filename2,'output_util.dat'),'-mat');
load(strcat(filename2,'output_temp.dat'),'-mat');
load(strcat(filename2,'entercnid.dat'),'-mat');

rs=[floor((idr1-1.45*output_gt(1,2))*1000)+1 floor((idr2-1.45*output_gt(1,2))*1000)+1];

% Calibration of warming in 2020 to 1C according to Figure SPM.2 in IPCC-AR6
tempref=1;
output_temp=output_temp-(output_temp(121,1,1)-tempref);
S_Bau(:,31,1)=S_Bau(:,31,1)-(S_Bau(121,31,1)-tempref);

cmap=hot(18);
for r=1:2
ytarget=196; % 221 for 2125 and 196 for 2100
s=-1;
dinc=zeros(Nnet,2*10);
dincxy=zeros(10,3);
di=0;
for coop=0:(cn_num-1)
emif=sum(S_Bau(49,20,entercnid(1:coop)+2),3)/sum(S_Bau(49,20,3:(cn_num+1)),3); % fraction of participation weighted by emissions
if emif>0.9999
    emif=1;
end
s1=floor(emif*10)+1;
if s1<=s
    continue;
end
xs = zeros(Nnet,3);
i=0;
for NET=1:31
    deltaU=1-(output_util(2,coop+1,NET,rs(r))-output_util(2,1,1,rs(r)))/output_util(2,1,1,rs(r)); % 2 for globe; 3-(cn_num+1) for countries
    if deltaU>0
        xrou=1-exp(log(deltaU)/elasmu2);
    else
        xrou=-1;
    end
    i=i+1;
    xs(i,1)=output_temp(ytarget,coop+1,NET);
    xs(i,2)=xrou;
    xs(i,3)=(NET-1)/10-1;
    if NET==11
        i2=i;
    end
end
s=s1;
di=di+1;
dinc(:,(di*2-1):(di*2))=xs(:,1:2);
dincxy(di,1)=i2;
dincxy(di,2)=i;
dincxy(di,3)=emif;
end

dincint=zeros(Nnet,2*11); 
dincxy2=zeros(11,4);
for i=1:(di-1)
    i1=floor(dincxy(i,3)*10)+1;
    i2=floor(dincxy(i+1,3)*10)+1;
    i3=dincxy(i+1,2);
    dincint(:,1:2)=dinc(:,1:2);
    for j3=i1+1:i2
        for j1=1:2
            for j2=1:i3
                if ((j3-1)*0.1-dincxy(i,3))==0
                    dincint(j2,j1+(j3-1)*2)=dinc(j2,j1+(i-1)*2);
                else
                    dincint(j2,j1+(j3-1)*2)=dinc(j2,j1+(i-1)*2)+(dinc(j2,j1+i*2)-dinc(j2,j1+(i-1)*2))/(dincxy(i+1,3)-dincxy(i,3))*((j3-1)*0.1-dincxy(i,3));
                end
            end
        end
       
    end
end


for i=1:11
    [B, IX] = sort(-dincint(:,i*2),1);
    dincxy2(i,1)=11;
    dincxy2(i,2)=31;
    dincxy2(i,3)=i*0.1-0.1;
    dincxy2(i,4)=IX(1);
end

dincint2=zeros(Nnet,2*11);
for i=1:11
    for j=1:(dincxy2(i,2)-4)
        x=dincint(j:(j+4),i*2-1);
        y=dincint(j:(j+4),i*2);
        [rreg,mreg,breg] = regression(x',y');
        dincint2(j,i*2-1)=dincint(j+2,i*2-1); % with technology
        dincint2(j,i*2)=-mreg;
    end
end

topt=zeros(11,2);
for i=1:11
    ix=max(1,dincxy2(i,4)-2);
    w2=0;
    for w=1:3
        if (ix+w)<1 || (ix+w)>(dincxy2(i,2)-4)
            continue;
        end
        if (dincint2(ix,i*2)*dincint2(ix+w,i*2))<=0
            w2=w;
            break;
        end
        w=-w;
        if (ix+w)<1 || (ix+w)>(dincxy2(i,2)-4)
            continue;
        end
        if (dincint2(ix,i*2)*dincint2(ix+w,i*2))<=0
            w2=w;
            break;
        end
    end
    w=w2;
    if (dincint2(ix+w,i*2)-dincint2(ix,i*2))==0
        topt(i,1)=dincint2(ix,i*2-1);
    else
        topt(i,1)=dincint2(ix,i*2-1)+(dincint2(ix+w,i*2-1)-dincint2(ix,i*2-1))/(dincint2(ix+w,i*2)-dincint2(ix,i*2))*(0-dincint2(ix,i*2));
    end
    topt(i,2)=dincint(ix+2,i*2);
end

subplot(2,1,r);
for i=1:11
    plot(dincint(1:dincxy2(i,2),i*2-1),dincint(1:dincxy2(i,2),i*2),'LineStyle','-','LineWidth',1,'Color',cmap(i,1:3)); hold on;
end
for i=1:11
    plot(dincint(dincxy2(i,1),i*2-1),dincint(dincxy2(i,1),i*2),'o','MarkerEdgeColor',cmap(i,1:3),'MarkerFaceColor',[1 1 1],'Markersize',4); hold on;
end
for i=1:11
    plot(topt(i,1),topt(i,2),'o','MarkerEdgeColor',cmap(i,1:3),'MarkerFaceColor',[0.8 1 1],'Markersize',4); hold on;
end
if r==1
    axis([1 dinc(1,1) 0 0.14]);
%     set(gca,'ytick',-0.02:0.1:0.08); set(gca,'xtick',1:3.5:4.5);
else
    axis([1 dinc(1,1) 0 0.03]);
%     set(gca,'ytick',-0.06:0.09:0.03); set(gca,'xtick',1:3.5:4.5);
end
colormap(cmap(1:11,1:3)); colorbar

% subplot(2,2,r+2);
% for i=1:11
%     plot(dincint2(1:(dincxy2(i,2)-4),i*2-1),dincint2(1:(dincxy2(i,2)-4),i*2),'LineStyle','-','LineWidth',1,'Color',cmap(i,1:3)); hold on;
% end
% for i=1:11
%     plot(dincint2(dincxy2(i,1)-2,i*2-1),dincint2(dincxy2(i,1)-2,i*2),'o','MarkerEdgeColor',cmap(i,1:3),'MarkerFaceColor',[1 1 1],'Markersize',4); hold on;
% end
% for i=1:11
%     plot(topt(i,1),0,'o','MarkerEdgeColor',cmap(i,1:3),'MarkerFaceColor',[0.8 1 1],'Markersize',4); hold on;
% end
% if r==1
%     axis([1 dinc(1,1) -0.05 0.15]);
% %     set(gca,'ytick',-0.02:0.1:0.08); set(gca,'xtick',1:3.5:4.5);
% else
%     axis([1 dinc(1,1) -0.06 0.03]);
% %     set(gca,'ytick',-0.06:0.09:0.03); set(gca,'xtick',1:3.5:4.5);
% end
% colormap(cmap(1:11,1:3)); colorbar

end

