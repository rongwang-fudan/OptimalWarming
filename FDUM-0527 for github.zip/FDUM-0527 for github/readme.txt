All files in this fold are for a paper that is under review.

Referring to the file <setting for different scenarios.xlsx>, run <fumccm.m> can obtain all the data files for different scenarios used in the paper.

Please use these files with caution, as the paper is still under review.

Data, code or files here may be modified.

A notification will be released when there is update of the data.

Rong Wang

27 May 2022

Contact: rongwang@fudan.edu.cn
