% Author: Rong Wang // contact rongwang@fudan.edu.cn //
% Date: 2021.12.20
% Assessing the contribution of different parameters to the uncertainty
% 1	Slope of regional temperature to global temperature lamba_region	-
% 2	Equilibrium sensitivity of climate	ESC	K/(W/m2)
% 3	Inertia of atmospheric surface temperature	INT	yr
% 4	Industrial CO2 emissions	indemi	-
% 5	LUC emissions	lucemi	-
% 6	C flux from air to terrestrial biosphere	Flux14	GtC/yr
% 7	C flux from air to surface ocean	Flux15	GtC/yr
% 8	C flux from terrestrial biosphere to soil	Flux42	GtC/yr
% 9	Turnover time of C in soil	LTsoil	yr
% 10	Turnover time of C in deep ocean	LTocean	yr
% 11	Radiative forcing of methan	rf_ch4	-
% 12	Radiative forcing of nitrogen oxide	rf_n2o	-
% 13	Radiative forcing of CFCs	rf_cfc	-
% 14	Radiative forcing of aerosols	rf_aer	-
% 15	Elasticity of substitution between energy and non-energy inputs	elas	-
% 16	Sensitivity of induced EUE change rate to the share of energy expenditure in total costs	ss_eue	-
% 17	Economic damage of 1C warming	dcoef	-
% 18	Learning rate	LR	-

function [ para_range ] = MonteCarlo_obs( FFlux, L, iec, xy_iec, output_cap, dpo, dcoef, LR, covidyear, tempdiff, iecone, climate_efficiency, technology_diffusion, negative_emissions )

unc=[1	1	1.028301887	0.9853	0.9412	1.068190855	1.060618557	1	0.959279794	0.907512099	1	1	1	1	1.147	1	1	1
4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4
1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1
1	0.25	0.056618611	0.008525322	0.04759881	0.065661642	0.07348367	0.128900256	0.024256415	0.086024407	0.1008	0.1008	0.1008	0.112	0.073234525	0.11	0.15	0.257142857
1	0.19	0.056618611	0.008525322	0.04759881	0.065661642	0.07348367	0.128900256	0.024256415	0.100558682	0.1008	0.1008	0.1008	0.112	0.073234525	0.11	0.15	0.514285714];

global  alpha elas theta2 econo0 clim0 EFco2 Egreen Fex Eland realtime carbonbudget20 cndata cou_iform

nmc=10000;
num1=11; % 21 for 0, 5, 10, ..., 100 percentiles; 11 for 0, 10, 20, ..., 100 percentiles
num2=18; % number of parameters
num3=num1*num2;
T = size(realtime,1);
cn_num=size(cndata,1);
para_range = zeros(num2,num1); % range of parameters

EFco20=EFco2;
carbonbudget20s=carbonbudget20;
Eland0 = Eland;
Fex0=Fex;
dcoef0=dcoef;
FFlux0=FFlux;
LR0=LR;
elas0=max(0.02,elas);

%Input of data by country: cndata(1+119,1+49*4) KEYL+Et+Ez
[econcn] = countrydata( output_cap, dpo, dcoef, cndata, tempdiff );

%Rates of induced efficiency changes by country
[iec_cn, slopecn] = IEC_cn( cndata, iec, xy_iec, 0 );

% regression of regional temperature with global temperature
regress_tempzone=zeros(11,4); %1  N Ame; 2 S Ame; 3 W Eur; 4 N Afr & Middle East; 5 S Afr; 6 E Eur; 7 E Asia; 8 S & SE Asia; 9 Oceania; 10 Polar; 11 Ocean
tempinput = load('files\temperature.txt'); % 764x12 (1 globe; 2-11 region; 12 for ocean)
tempinputyy=zeros(63,12);
for yy=1:63
    tempinputyy(yy,1:12)=mean(tempinput((yy*12-11):(yy*12),1:12),1);
end
for regionid=1:11
    [b2,bint2,r2,rint2,stats2]=regress(tempinputyy(:,regionid+1),[ones(63,1) tempinputyy(:,1)]);
    regress_tempzone(regionid,1)=b2(2,1); % slope
    regress_tempzone(regionid,2)=(bint2(2,2)-bint2(2,1))/1.96/2; % std of slope
    regress_tempzone(regionid,3)=mean(tempinputyy(:,regionid+1),1); % ave of y
    regress_tempzone(regionid,4)=mean(tempinputyy(:,1),1); % ave of x
end

for mc=1:(num3+nmc)
% for mc=1:22
    
% if mod(mc,500)==1
    display(mc);
% end

pset=ones(1,num2);
if mc>num3
    % 1, generate a random value
    for j=1:num2
        pset(j) = min(2, max(0.1,randvar(unc(2:5,j),1,0)));
    end
else
    % 2, select the percentile i for parameter j
    i=mod(mc-1,num1) * 100 / (num1-1); % percentile
    j=floor((mc-1)/num1)+1; % parameter
    pset(j) = randvar(unc(2:5,j),2,i);
end

pset=pset.*unc(1,:);
% pset(16)=min(2,max(0,pset(16)));
% pset(17)=min(2,max(0,pset(17)));

tempzone=zeros(11,2);
for regionid=1:11
    if mc<=num3
        tempzone(regionid,1) = max(0,min(2.5,regress_tempzone(regionid,1) + regress_tempzone(regionid,2) * (pset(1)-1))); % slope of the varied curve
    else
        pset(1) = min(2,max(0.1,randvar(unc(2:5,1),1,0))); % make the regional curve independent to each other
        tempzone(regionid,1) = max(0,min(2.5,regress_tempzone(regionid,1) + regress_tempzone(regionid,2) * (pset(1)-1))); % slope of the varied curve
    end
    tempzone(regionid,2) = regress_tempzone(regionid,3) - regress_tempzone(regionid,4) * tempzone(regionid,1); % intercept of the varied curve
end

%Elasticity of substitution (avoid a zero-like elas)
elas = elas0 * max(0.04/elas0, pset(15));
%Coefficient in the damage function
dcoef = dcoef0 * pset(17);
%Learning rate on the cost curve
LR = LR0 * pset(18);

%Equilibrium sensitivity of climate
FFlux(1) = FFlux0(1) * pset(2);
%Time inertia of climate system to reach equilibirum (year)
FFlux(2) = FFlux0(2) * pset(3);
%air to land biosphere GtC/yr
FFlux(4) = FFlux0(4) * pset(6);
%air to surface ocean GtC/yr
FFlux(5) = FFlux0(5) * pset(7);
%land biosphere to soil GtC/yr
FFlux(6) = FFlux0(6) * pset(8);
%surface soil to deep soil GtC/yr
FFlux(7) = FFlux0(7) / pset(9);
%surface ocean to deep ocean GtC/yr
FFlux(8) = FFlux0(8) / pset(10);

%CO2 emission factors for fossil fuel only tCO2 / MJ
EFco2 = EFco20 * pset(4);
carbonbudget20(:,2) = carbonbudget20s(:,2) * pset(4);
%CO2 emissions from land use change
Eland = Eland0 * pset(5);
%Radiative forcing by 1 CH4, 2 N2O, 3 CFCs, 4 aerosol
for i=1:4
    Fex(:,i) = Fex0(:,i) * pset(i+10);
end


%Initial population (millions)
L0 = L(1,1);
%Initial level of total factor productivity
A0 = econo0(13) / (econo0(10)^alpha) / (L0/1000)^(1-alpha);
%Energy use efficiency $ / KJ
econo0(1) = econo0(15)^(elas/(elas-1)) / (econo0(12)/econo0(13));
%Energy production efficiency PJ / (trillion $)^0.3 / (billion cap)^0.7
econo0(2) = (A0^(elas-1) * econo0(15))^(1/(elas-1)) / econo0(1);
%Non-energy efficiency (trillion $)^0.7 / (billion cap)^0.7
econo0(3) = (A0^(elas-1) * (1-econo0(15)))^(1/(elas-1));
%Abatement cost as a percentage of GDP
econo0(5) = econo0(4) / theta2 * econo0(18)^theta2  * econo0(12) / econo0(13) * EFco2(1) / 1000;
%Industrial emissions (Gt CO2 per year)
econo0(20) = econo0(12) * EFco2(1,1) * (1-Egreen(1,8));

% switcher for  C1	C2	S1	S2	S3	S4	S5	T1	T2	T3	T4
switcher = ones(1,10);

%Calibration of climate damage function
% [output_dam] = Calibration_DAM( dcoef, dpo, xy_damage );
% save('..\output\output_dam.dat','output_dam');

%Calibration of equilibrium sensitivity of climate
% [output_esc] = Calibration_ESC( FFlux, 0 );

%Calibration of savings rate by capital, energy and ouput
[calrsav, output_cap] = Calibration_CAP( L, iec, dpo, dcoef, LR, switcher, 0 );

%Calibration of ENE reduction by COVID-19
[output_covid, deffs] = Calibration_COVID( FFlux, L, iec, calrsav, dpo, dcoef, LR, switcher, covidyear, 0 );

% abatement setting by country
abtcn=zeros(cn_num,3);
abtcn(1:cn_num,1)=2025;
abtcn(1:cn_num,2)=1;
abtcn(1:cn_num,3)=10;

%Scenarios
elasmu=1.45; % elasticity of marginal utility of consumption
U0 = ((1-calrsav(5)).* output_cap(45,29)./L(45,1)*1000)^(1-elasmu)/(1-elasmu); % utility in 2015
t=[5:5:25];
% SCN=zeros(T,35,cn_num+1,14);
output_temp=zeros(cn_num+1+11,14); % Atmospheric temperature without mitigation
output_consu=zeros(400,cn_num+1+9,16);
if climate_efficiency==2
    switcher(2)=0; % deactivating the impact of climate change on efficieney of ENE
    switcher(4)=0; % deactivating the impact of climate change on efficieney of EUE
end
for s=1:15
    abtcn(1:cn_num,1)=2020+s*5;
    if s==15 % Business as usual
        abtcn(1:cn_num,1)=2025;
        abtcn(1:cn_num,3)=200;
    end
    NET = 1;
    S8 = Abatementzone( FFlux, L, dpo, dcoef, LR, covidyear, iec, iec_cn, calrsav, deffs, switcher, econcn, cndata, abtcn, tempzone, tempdiff, iecone, technology_diffusion, negative_emissions, NET );
%     SCN(:,:,:,s)=S8;
    % Atmospheric temperature without mitigation
    if s==14
        output_temp(1,1:14)=S8(121:5:186,31,1); % Global warming without mitigation
        for cn=1:cn_num
            output_temp(cn+1,1:14)=S8(121:5:186,31,cn+1); % Atmospheric temperature difference to 13 C without mitigation
        end
        for cnzone=1:11
            output_temp(cn_num+1+cnzone,1:14)=S8(121:5:186,31,1)*tempzone(cnzone,1)+tempzone(cnzone,2); % Regional warming without mitigation
        end
    end
    % Consumption
    for j=1:400
        if j<33
            rsav=calrsav(3);
        elseif j<38
            rsav=calrsav(4);
        else
            rsav=calrsav(5);
        end
        output_consu(j,1,s)=(1-rsav)* S8(j,7,1); % Global Consumption
        output_consu(j,1,16)=S8(j,35,1); % Global Population
        for cn=1:cn_num
            output_consu(j,cn+1,s)=(1-rsav)*S8(j,7,cn+1); % Consumption
            output_consu(j,cn+1,16)=S8(j,35,cn+1); % Population
            if cn>1
                cnzone=cou_iform(cndata(cn,1),7); % Region ID 1-11
                output_consu(j,cn_num+1+cnzone,s)=output_consu(j,cn_num+1+cnzone,s)+(1-rsav)* S8(j,7,cn+1); % Regional Consumption
                output_consu(j,cn_num+1+cnzone,16)=output_consu(j,cn_num+1+cnzone,16)+S8(j,35,cn+1); % Regional Population
            end
        end
    end
end

%Output parameters
parameters=zeros(56+71*3+22,1);
parameters(1,1) = dcoef;
parameters(2,1) = FFlux(1); % ESC
parameters(3,1) = FFlux(2); % Inertia time
parameters(4,1) = output_cap(45,20); % total emissions for 2015
parameters(5,1) = Eland(45,1); % total emissions for 2015
parameters(6:8,1) = FFlux(4:6);
parameters(9,1) = clim0(2)/FFlux(7);
parameters(10,1) = clim0(5)/FFlux(8);
parameters(11:14,1) = Fex(45,1:4);
parameters(15,1) =  elas;
parameters(16,1) = (xy_iec(1,6)-xy_iec(4,6))/(log(xy_iec(1,4))-log(xy_iec(4,4))); % (dEUE/EUE)/(dOmega/Omega)
parameters(17,1) = (xy_iec(1,8)-xy_iec(4,8))/(log(xy_iec(1,5))-log(xy_iec(4,5))); % (dENE/ENE)/(dOmega/Omega)
parameters(18,1) = LR;
parameters(19:23,1) = calrsav(1,1:5);
parameters(24:34,1) = deffs(1,1:11);
parameters(35:45,1) = deffs(2,1:11);
parameters(46:56,1) = deffs(3,1:11);
parameters(57:127,1) = iec(1,1:71); % EUE rate
parameters(128:198,1) = iec(2,1:71); % EPE rate
parameters(199:269,1) = iec(4,1:71); % ENE rate
parameters(270:280,1) = tempzone(1:11,1); % temperature slope
parameters(281:291,1) = tempzone(1:11,2); % temperature intercept
if mc<=num3
    i=mod(mc-1,num1)+1; % percentile
    j=floor((mc-1)/num1)+1; % parameter
    para_range(j,i) = parameters(j,1);
end

save(strcat('D:\monte carlo_cn\parameters-mc',num2str(mc),'.dat'),'parameters');
save(strcat('D:\monte carlo_cn\output_temp-mc',num2str(mc),'.dat'),'output_temp');
save(strcat('D:\monte carlo_cn\output_consu-mc',num2str(mc),'.dat'),'output_consu'); % 1 globe; 2 globe; 3-114 by country

end

save('D:\monte carlo_cn\para_range.dat','para_range');
save('D:\monte carlo_cn\population.dat','L');

end







