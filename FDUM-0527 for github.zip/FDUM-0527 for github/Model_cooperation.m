% Author: Rong Wang // contact rongwang@fudan.edu.cn //
% Date: 2021.12.20
% Assessing the contribution of different parameters to the uncertainty
% 1	Slope of regional temperature to global temperature lamba_region	-
% 2	Equilibrium sensitivity of climate	ESC	K/(W/m2)
% 3	Inertia of atmospheric surface temperature	INT	yr
% 4	Industrial CO2 emissions	indemi	-
% 5	LUC emissions	lucemi	-
% 6	C flux from air to terrestrial biosphere	Flux14	GtC/yr
% 7	C flux from air to surface ocean	Flux15	GtC/yr
% 8	C flux from terrestrial biosphere to soil	Flux42	GtC/yr
% 9	Turnover time of C in soil	LTsoil	yr
% 10	Turnover time of C in deep ocean	LTocean	yr
% 11	Radiative forcing of methan	rf_ch4	-
% 12	Radiative forcing of nitrogen oxide	rf_n2o	-
% 13	Radiative forcing of CFCs	rf_cfc	-
% 14	Radiative forcing of aerosols	rf_aer	-
% 15	Elasticity of substitution between energy and non-energy inputs	elas	-
% 16	Sensitivity of induced EUE change rate to the share of energy expenditure in total costs	ss_eue	-
% 17	Economic damage of 1C warming	dcoef	-
% 18	Learning rate	LR	-

function [ output_gt, entercnid ] = Model_cooperation( FFlux, L, iec, xy_iec, output_cap, dpo, dcoef, LR, covidyear, tempdiff, iecone, climate_economy, enterseq, technology_diffusion, transtime, translen, negative_emissions, singles )

unc=[1	1	1.028301887	0.9853	0.9412	1.068190855	1.060618557	1	0.959279794	0.907512099	1	1	1	1	1.147	1	1	1
4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4	4
1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1
1	0.25	0.056618611	0.008525322	0.04759881	0.065661642	0.07348367	0.128900256	0.024256415	0.086024407	0.1008	0.1008	0.1008	0.112	0.073234525	0.11	0.15	0.257142857
1	0.19	0.056618611	0.008525322	0.04759881	0.065661642	0.07348367	0.128900256	0.024256415	0.100558682	0.1008	0.1008	0.1008	0.112	0.073234525	0.11	0.15	0.514285714];

global  alpha elas theta2 econo0 clim0 EFco2 Egreen Fex Eland realtime carbonbudget20 cndata cou_iform

nmc=10000;
num1=11; % 21 for 0, 5, 10, ..., 100 percentiles; 11 for 0, 10, 20, ..., 100 percentiles
num2=18; % number of parameters
num3=num1*num2;
T = 400;
cn_num=size(cndata,1);
% para_range = zeros(num2,num1); % range of parameters

EFco20=EFco2;
carbonbudget20s=carbonbudget20;
Eland0 = Eland;
Fex0=Fex;
dcoef0=dcoef;
FFlux0=FFlux;
LR0=LR;
elas0=max(0.02,elas);

%Input of data by country: cndata(1+119,1+49*4) KEYL+Et+Ez
[econcn] = countrydata( output_cap, dpo, dcoef, cndata, tempdiff );

%Rates of induced efficiency changes by country

[iec_cn, slopecn] = IEC_zone( cndata );


% regression of regional temperature with global temperature
regress_tempzone=zeros(11,4); %1  N Ame; 2 S Ame; 3 W Eur; 4 N Afr & Middle East; 5 S Afr; 6 E Eur; 7 E Asia; 8 S & SE Asia; 9 Oceania; 10 Polar; 11 Ocean
tempinput = load('files\temperature.txt'); % 764x12 (1 globe; 2-11 region; 12 for ocean)
tempinputyy=zeros(63,12);
for yy=1:63
    tempinputyy(yy,1:12)=mean(tempinput((yy*12-11):(yy*12),1:12),1);
end
for regionid=1:11
    [b2,bint2,r2,rint2,stats2]=regress(tempinputyy(:,regionid+1),[ones(63,1) tempinputyy(:,1)]);
    regress_tempzone(regionid,1)=b2(2,1); % slope
    regress_tempzone(regionid,2)=(bint2(2,2)-bint2(2,1))/1.96/2; % std of slope
    regress_tempzone(regionid,3)=mean(tempinputyy(:,regionid+1),1); % ave of y
    regress_tempzone(regionid,4)=mean(tempinputyy(:,1),1); % ave of x
end

mc=1;

pset=ones(1,num2);

pset=pset.*unc(1,:);

tempzone=zeros(11,2);
for regionid=1:11
    if mc<=num3
        tempzone(regionid,1) = max(0,min(2.5,regress_tempzone(regionid,1) + regress_tempzone(regionid,2) * (pset(1)-1))); % slope of the varied curve
    else
        pset(1) = min(2,max(0.1,randvar(unc(2:5,1),1,0))); % make the regional curve independent to each other
        tempzone(regionid,1) = max(0,min(2.5,regress_tempzone(regionid,1) + regress_tempzone(regionid,2) * (pset(1)-1))); % slope of the varied curve
    end
    tempzone(regionid,2) = regress_tempzone(regionid,3) - regress_tempzone(regionid,4) * tempzone(regionid,1); % intercept of the varied curve
end

%Elasticity of substitution (avoid a zero-like elas)
elas = elas0 * max(0.04/elas0, pset(15));
%Coefficient in the damage function
dcoef = dcoef0 * pset(17);
%Learning rate on the cost curve
LR = LR0 * pset(18);

%Equilibrium sensitivity of climate
FFlux(1) = FFlux0(1) * pset(2);
%Time inertia of climate system to reach equilibirum (year)
FFlux(2) = FFlux0(2) * pset(3);
%air to land biosphere GtC/yr
FFlux(4) = FFlux0(4) * pset(6);
%air to surface ocean GtC/yr
FFlux(5) = FFlux0(5) * pset(7);
%land biosphere to soil GtC/yr
FFlux(6) = FFlux0(6) * pset(8);
%surface soil to deep soil GtC/yr
FFlux(7) = FFlux0(7) / pset(9);
%surface ocean to deep ocean GtC/yr
FFlux(8) = FFlux0(8) / pset(10);

%CO2 emission factors for fossil fuel only tCO2 / MJ
EFco2 = EFco20 * pset(4);
carbonbudget20(:,2) = carbonbudget20s(:,2) * pset(4);
%CO2 emissions from land use change
Eland = Eland0 * pset(5);
%Radiative forcing by 1 CH4, 2 N2O, 3 CFCs, 4 aerosol
for i=1:4
    Fex(:,i) = Fex0(:,i) * pset(i+10);
end

%Initial population (millions)
L0 = L(1,1);
%Initial level of total factor productivity
A0 = econo0(13) / (econo0(10)^alpha) / (L0/1000)^(1-alpha);
%Energy use efficiency $ / KJ
econo0(1) = econo0(15)^(elas/(elas-1)) / (econo0(12)/econo0(13));
%Energy production efficiency PJ / (trillion $)^0.3 / (billion cap)^0.7
econo0(2) = (A0^(elas-1) * econo0(15))^(1/(elas-1)) / econo0(1);
%Non-energy efficiency (trillion $)^0.7 / (billion cap)^0.7
econo0(3) = (A0^(elas-1) * (1-econo0(15)))^(1/(elas-1));
%Abatement cost as a percentage of GDP
econo0(5) = econo0(4) / theta2 * econo0(18)^theta2  * econo0(12) / econo0(13) * EFco2(1) / 1000;
%Industrial emissions (Gt CO2 per year)
econo0(20) = econo0(12) * EFco2(1,1) * (1-Egreen(1,8));

% switcher for  C1	C2	S1	S2	S3	S4	S5	T1	T2	T3	T4
switcher = ones(1,10);

%Calibration of climate damage function
% [output_dam] = Calibration_DAM( dcoef, dpo, xy_damage );
% save('..\output\output_dam.dat','output_dam');

%Calibration of equilibrium sensitivity of climate
% [output_esc] = Calibration_ESC( FFlux, 0 );

%Calibration of savings rate by capital, energy and ouput
[calrsav, output_cap] = Calibration_CAP( L, iec, dpo, dcoef, LR, switcher, 0 );

%Calibration of ENE reduction by COVID-19
[output_covid, deffs] = Calibration_COVID( FFlux, L, iec, calrsav, dpo, dcoef, LR, switcher, covidyear, 0 );

%Scenarios
if climate_economy==2
    switcher(2)=0; % deactivating the impact of climate change on efficieney of ENE
    switcher(4)=0; % deactivating the impact of climate change on efficieney of EUE
end

% BAU Scenario
abtcn=zeros(cn_num,3);
abtcn(:,1)=transtime;
abtcn(:,2)=1;
abtcn(:,3)=100;
S_Bau = Abatementzone( FFlux, L, dpo, dcoef, LR, covidyear, iec, iec_cn, calrsav, deffs, switcher, econcn, cndata, abtcn, tempzone, tempdiff, iecone, technology_diffusion, 2, 0 );
elasmu=1.45; % elasticity of marginal utility of consumption
disc=zeros(400,cn_num+1,50);
for cn=1:(cn_num+1)
    for j=121:400
        for r=1:50
            disc(j,cn,r)=((1-calrsav(5))*1000/S_Bau(j,35,cn))^(1-elasmu)/(1-elasmu)*S_Bau(j,35,cn)/1000*(1-r*0.001)^(realtime(j,1)-2020);
        end
    end
end
output_gt=zeros(cn_num+1+5,14*3);
for cn=1:(cn_num+1)
    for s=1:14
        output_gt(cn,s)=log(S_Bau(121+s*5,7,cn)/S_Bau(111+s*5,7,cn))/10; % Growth rate in consumption in 2025, 2035, ..., 2080
        output_gt(cn,s+14)=(1-calrsav(5))*S_Bau(116+s*5,7,cn); % consumption in the year of mitigation in 2025, 2035, ..., 2080
        output_gt(cn,s+28)=S_Bau(116+s*5,35,cn); % population in 2025, 2035, ..., 2080
        if cn>=3
            zone4=cou_iform(cndata(cn-1,1),4); % 1 OCED/ 2 REF/ 3 ASIA/4 ALM
            output_gt(zone4+cn_num+1,s+14)=output_gt(zone4+cn_num+1,s+14)+output_gt(cn,s+14);
            output_gt(zone4+cn_num+1,s+28)=output_gt(zone4+cn_num+1,s+28)+output_gt(cn,s+28);
            output_gt(5+cn_num+1,s+14)=output_gt(5+cn_num+1,s+14)+output_gt(cn,s+14);
            output_gt(5+cn_num+1,s+28)=output_gt(5+cn_num+1,s+28)+output_gt(cn,s+28);
        end
    end
end

% Mitigation in 2025
util2025=zeros(cn_num+1+5,50,3);
abtcn(:,3)=translen;
S_Act = Abatementzone( FFlux, L, dpo, dcoef, LR, covidyear, iec, iec_cn, calrsav, deffs, switcher, econcn, cndata, abtcn, tempzone, tempdiff, iecone, technology_diffusion, 2, 0 );
abtcn(:,1)=transtime+30;
S_Act2 = Abatementzone( FFlux, L, dpo, dcoef, LR, covidyear, iec, iec_cn, calrsav, deffs, switcher, econcn, cndata, abtcn, tempzone, tempdiff, iecone, technology_diffusion, 2, 0 );
j=121; % 2025
while realtime(j,1)<=2300
    for cn=1:(cn_num+1)
        for r=1:50
            u1=(S_Bau(j,7,cn))^(1-elasmu)*disc(j,cn,r);  % NPV of utility BAU
            u2=(S_Act(j,7,cn))^(1-elasmu)*disc(j,cn,r);  % NPV of utility Mitigation
            u3=(S_Act2(j,7,cn))^(1-elasmu)*disc(j,cn,r);  % NPV of utility Mitigation
            util2025(cn,r,1)=util2025(cn,r,1)+u1;  % NPV of utility BAU
            util2025(cn,r,2)=util2025(cn,r,2)+u2;  % NPV of utility Mitigation
            util2025(cn,r,3)=util2025(cn,r,3)+u3;  % NPV of utility Mitigation
            if cn>=3
                zone4=cou_iform(cndata(cn-1,1),4); % 1 OCED/ 2 REF/ 3 ASIA/4 ALM
                util2025(cn_num+1+zone4,r,1)=util2025(cn_num+1+zone4,r,1)+u1;  % NPV of utility BAU
                util2025(cn_num+1+zone4,r,2)=util2025(cn_num+1+zone4,r,2)+u2;  % NPV of utility Mitigation
                util2025(cn_num+1+zone4,r,3)=util2025(cn_num+1+zone4,r,3)+u3;  % NPV of utility Mitigation
                util2025(cn_num+1+5,r,1)=util2025(cn_num+1+5,r,1)+u1;  % NPV of utility BAU
                util2025(cn_num+1+5,r,2)=util2025(cn_num+1+5,r,2)+u2;  % NPV of utility Mitigation
                util2025(cn_num+1+5,r,3)=util2025(cn_num+1+5,r,3)+u3;  % NPV of utility Mitigation
            end
        end
    end
    j=j+1;
end

% Control Exp
% abtcn(:,1)=2250;
% S_CTR = Abatementzone( FFlux, L, dpo, dcoef, LR, covidyear, iec, iec_cn, calrsav, deffs, switcher, econcn, cndata, abtcn, tempzone, tempdiff, iecone, technology_diffusion, 2, 0 );
% abtcn(:,1)=transtime;
% S_CTR2 = Abatementzone( FFlux, L, dpo, dcoef, LR, covidyear, iec, iec_cn, calrsav, deffs, switcher, econcn, cndata, abtcn, tempzone, tempdiff, iecone, technology_diffusion, 2, -1 );

if enterseq==1
    emi2025=zeros(cn_num-1,1);
    emi2025(1:(cn_num-1),1)=S_Bau(49,20,3:(cn_num+1));
    [B, entercnid] = sort(-emi2025, 1);  % emission 2020
elseif enterseq==2
    percapGDP2025=zeros(cn_num-1,1);
    percapGDP2025(1:(cn_num-1),1)=S_Bau(49,7,3:(cn_num+1))./S_Bau(49,35,3:(cn_num+1));
    [B, entercnid] = sort(-percapGDP2025, 1);  % per capita GDP 2020
elseif enterseq==3
    EI2025=zeros(cn_num-1,1);
    EI2025(1:(cn_num-1),1)=S_Bau(49,20,3:(cn_num+1))./S_Bau(49,7,3:(cn_num+1));
    [B, entercnid] = sort(-EI2025, 1);   % emission intensity 2020
end

% scenarios of mitigation with cooperation
Nnet=31;
output_util=zeros(cn_num+1+5,cn_num-1+7,Nnet,50);
output_temp=zeros(400,cn_num-1+7,Nnet);
output_emi=zeros(400,cn_num-1+7,Nnet);
output_ene=zeros(400,cn_num-1+7,Nnet);
output_gdp=zeros(400,cn_num-1+7,Nnet);
output_zcenergy=zeros(400,cn_num-1+7,Nnet);
output_mac=zeros(400,cn_num-1+7,Nnet,4);
cnChina=find(cndata(:,1)==43);
cnUS=find(cndata(:,1)==212);
for NET=1:Nnet
    display(NET);
    NETs=(NET-1)/10-1;
    abtcn(:,1)=transtime+30;
    abtcn(:,2)=1;
    abtcn(:,3)=translen;
    abtcn(1,1)=transtime;
    for coop=1:(cn_num+6)
%         display(coop);
        if singles==2
            abtcn(2:cn_num,1)=transtime+30; % only one country/region mitigate early
        end
        if coop>1 && coop<=cn_num
            abtcn(entercnid(coop-1)+1,1)=transtime;
        else
            if coop==(cn_num+1)
                abtcn(2:cn_num,1)=transtime+30;
            end
            for cn=1:(cn_num-1)
                if cou_iform(cndata(cn+1,1),4)==(coop-cn_num) || coop>=(cn_num+5)
                    abtcn(cn+1,1)=transtime; % early action in order of 1 OCED 2 REF 3 ASIA 4 ALM
                end
            end
        end
        if coop==(cn_num+6)
            S8 = Abatementzone( FFlux, L, dpo, dcoef, LR, covidyear, iec, iec_cn, calrsav, deffs, switcher, econcn, cndata, abtcn, tempzone, tempdiff, iecone, 4, negative_emissions, NETs ); % no technology cooperation
        else
            S8 = Abatementzone( FFlux, L, dpo, dcoef, LR, covidyear, iec, iec_cn, calrsav, deffs, switcher, econcn, cndata, abtcn, tempzone, tempdiff, iecone, technology_diffusion, negative_emissions, NETs );
        end
        output_temp(1:400,coop,NET)=S8(1:400,31,1); % Atmospheric temperature, C
        output_emi(1:400,coop,NET)=sum(S8(1:400,20,3:(cn_num+1)),3); % CO2 emissions, Gt CO2
        output_ene(1:400,coop,NET)=sum(S8(1:400,12,3:(cn_num+1)),3); % Energy, PWh
        output_zcenergy(1:400,coop,NET)=sum(S8(1:400,21,3:(cn_num+1)),3); % ZC energy, PWh
        output_mac(1:400,coop,NET,1)=S8(1:400,4,cnChina+1); % Marginal cost of CO2 emission abatements in China, $/tCO2
        output_mac(1:400,coop,NET,2)=S8(1:400,4,cnUS+1);
        output_mac(1:400,coop,NET,3)=S8(1:400,12,cnChina+1);
        output_mac(1:400,coop,NET,4)=S8(1:400,12,cnUS+1);
        output_mac(1:400,coop,NET,5)=S8(1:400,21,cnChina+1);
        output_mac(1:400,coop,NET,6)=S8(1:400,21,cnUS+1);
        output_gdp(1:400,coop,NET)=sum(S8(1:400,7,3:(cn_num+1)),3); % GDP, trillion $
        % 1 globe; 2 globe; 3-136 by country; 137-140 OCED/REF/ASIA/ALM; 141 World
        j=121; % 2025
        while realtime(j,1)<=2300
            for cn=1:(cn_num+1)
                if cn==2
                    Us = (sum(S8(j,7,3:(cn_num+1)),3))^(1-elasmu); % global utility
                else
                    Us = (S8(j,7,cn))^(1-elasmu); % utility by country
                end
                for r=1:50
                    Uscn = Us*disc(j,cn,r);
                    output_util(cn,coop,NET,r) = output_util(cn,coop,NET,r) + Uscn;  % NPV of utility
                    if cn>=3
                        zone4=cou_iform(cndata(cn-1,1),4); % 1 OCED/ 2 REF/ 3 ASIA/4 ALM
                        output_util(zone4+cn_num+1,coop,NET,r) = output_util(zone4+cn_num+1,coop,NET,r) + Uscn;  % Sum of NPV of utility
                        output_util(5+cn_num+1,coop,NET,r) = output_util(5+cn_num+1,coop,NET,r) + Uscn;  % Sum of NPV of utility
                    end
                end
            end
            j=j+1;
        end
    end
end

if elas>0.55
    filename=strcat('..\cooperation\elas060climate_economy',num2str(climate_economy),'tech',num2str(technology_diffusion),'_NET',num2str(negative_emissions),'_SEQ',num2str(enterseq),'_Single',num2str(singles),'_transtime',num2str(transtime),'_translen',num2str(translen));
elseif elas<0.25
    filename=strcat('..\cooperation\elas010climate_economy',num2str(climate_economy),'tech',num2str(technology_diffusion),'_NET',num2str(negative_emissions),'_SEQ',num2str(enterseq),'_Single',num2str(singles),'_transtime',num2str(transtime),'_translen',num2str(translen));
else
    if dpo<2.5
        filename=strcat('..\cooperation\climate_economy',num2str(climate_economy),'tech',num2str(technology_diffusion),'_NET',num2str(negative_emissions),'_SEQ',num2str(enterseq),'_Single',num2str(singles),'_transtime',num2str(transtime),'_translen',num2str(translen));
    elseif dpo>2.5
        filename=strcat('..\cooperation\dpo3climate_economy',num2str(climate_economy),'tech',num2str(technology_diffusion),'_NET',num2str(negative_emissions),'_SEQ',num2str(enterseq),'_Single',num2str(singles),'_transtime',num2str(transtime),'_translen',num2str(translen));
    end
end
save(strcat(filename,'yr-output_util.dat'),'output_util');
save(strcat(filename,'yr-output_temp.dat'),'output_temp');
save(strcat(filename,'yr-output_emi.dat'),'output_emi');
save(strcat(filename,'yr-output_ene.dat'),'output_ene');
save(strcat(filename,'yr-output_zcenergy.dat'),'output_zcenergy');
save(strcat(filename,'yr-output_mac.dat'),'output_mac');
save(strcat(filename,'yr-output_gdp.dat'),'output_gdp');
save(strcat(filename,'yr-entercnid.dat'),'entercnid');
save(strcat(filename,'yr-output_gt.dat'),'output_gt');
save(strcat(filename,'yr-util2025.dat'),'util2025');
save(strcat(filename,'yr-S_Bau.dat'),'S_Bau');
save(strcat(filename,'yr-S_Act.dat'),'S_Act');
save(strcat(filename,'yr-S_Act2.dat'),'S_Act2');
save('..\cooperation\disc.dat','disc');

end







