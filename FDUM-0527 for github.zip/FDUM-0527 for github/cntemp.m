tic
clear;

load('files\cndata134.dat','-mat');
cndata=cndata2; clear cndata2;
cou_iform=load('files\country_information.txt');  % 222* 5 + 6 for annual mean temp + 7-18 for monthly mean temp

for i=1:222
    idx=find(cndata(:,1)==i);
    if size(idx,1)>0
        cou_iform(i,5)=idx(1)-1;
    end
end

T_china=cou_iform(43,6);
T_brazil=cou_iform(28,6);
for mm=6:6
    x=cou_iform(:,mm);
    for cn=1:222
        if cou_iform(cn,3)<=3
            x(cn)=max(20,x(cn));
        elseif cou_iform(cn,3)==5 || cou_iform(cn,3)==6
            x(cn)=max(10,min(28,x(cn)));
        else
            if x(cn)<-990
                x(cn)=13;
            else
                % correction to temperature in Figure 2 
                % Burke 2015. Global non-linear effect of temperature on economic production[J]. Nature.
                % Brazil 22C and China 14C
                x(cn)=max(5,min(28,14+(22-14)/(T_brazil-T_china)*(x(cn)-T_china)));
            end
        end
    end
    % correction to temperature in Figure 1
    % Burke 2018. Large potential reduction in economic damages under UN mitigation targets. Nature.
    % 90% Temperature between 10.5 and 18
    ts=prctile(x,[5 25 50 75 95]); % du/ds by year
    for cn=1:222
        x(cn)=max(10.5,min(15,10.5+(18-10.5)/(ts(5)-ts(1))*(x(cn)-ts(1))));
%         x(cn)=max(10,min(18,10.5+(16-10.5)/(ts(5)-ts(1))*(x(cn)-ts(1))));
    end
    x(43)=12.8; % Figure 2 in Burke 2015. Nature.
    cou_iform(1:cn,mm)=x;
end

cou_iform2=cou_iform(:,1:6);

save('files\cou_iform.dat','cou_iform2');
