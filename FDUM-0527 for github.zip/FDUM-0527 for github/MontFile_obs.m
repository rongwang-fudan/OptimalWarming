% Author: Rong Wang // contact rongwang@fudan.edu.cn //
% Date: 2021.12.20
tic
clear;

realtime = xlsread('files\time.xlsx');
realtime(:,1) = realtime(:,1) + 0.00001;

load('files\cndata134.dat','-mat');
cndata=cndata2; clear cndata2;
load('files\cou_iform.dat','-mat'); % 1: id for 222 countries; 2: 2 developing/ 1 developed; 3: 12 region id; 4 OECD; 5 id for 112 countries; 6 pi temperature
cou_iform=cou_iform2; clear cou_iform2;
cn_num=size(cndata,1); % 135

num1=11; % 21 for 0, 5, 10, ..., 100 percentiles; 11 for 0, 10, 20, ..., 100 percentiles
num2=18; % number of parameters
num3=num1*num2;
nmc=10000+num3;
% nmc=num3;

for simu=1:2

elasmu=1.45; % elasticity of marginal utility of consumption
U0 = ((1-0.25).* 105.1./7334*1000)^(1-elasmu)/(1-elasmu); % utility in 2015
t=[5:5:25];
idr=0.047; % intergenerational discount rate in 2025
r=idr-1.45*0.016; % social time preference of consumption
output_util=zeros(nmc,cn_num+1+11,55);
% 1 globe; 2 globe; 3-136 by country; 137-145 for 9 zone; 146 for sum of countries
% 1 N Ame; 2 S Ame; 3 W Eur; 4 N Afr & Middle East; 5 S Afr; 6 Russia; 7 E Asia; 8 S & SE Asia; 9 Oceania; 10 Polar; 11 Ocean
% 1-14 Utotal; 15-24  dU/dt; 25-34 temperature in 2025, 2030, 2035 ... 2070
% 35 rate of consumption growth in 2030
% 36-45 per capital consumption in 2025, 2030, 2035 ... 2070
% 46-55 population in 2025, 2030, 2035 ... 2070
for mc=1:nmc
    display(mc);
    if simu==1
        load(strcat('D:\monte carlo_cn11_standard\output_temp-mc',num2str(mc),'.dat'),'-mat');  % 1 globe; 2 globe; 3-114 by country; 115-125 for 11 zone
        load(strcat('D:\monte carlo_cn11_standard\output_consu-mc',num2str(mc),'.dat'),'-mat');  % 1 globe; 2 globe; 3-114 by country; 115-123 for 9 zone
    elseif simu==2
        load(strcat('D:\monte carlo_cn21_noIEC\output_temp-mc',num2str(mc),'.dat'),'-mat');  % 1 globe; 2 globe; 3-114 by country; 115-125 for 11 zone
        load(strcat('D:\monte carlo_cn21_noIEC\output_consu-mc',num2str(mc),'.dat'),'-mat');  % 1 globe; 2 globe; 3-114 by country; 115-123 for 9 zone
    end
    totalconsu=sum(output_consu(:,3:(cn_num+1),:),2);
    for s=1:14 
        j=121; % 2025
        while realtime(j,1)<=2300            
            for cn=1:(cn_num+10)
                if output_consu(j,cn,16)>0
                    Us = ((output_consu(j,cn,s)/output_consu(j,cn,16)*1000)^(1-elasmu)/(1-elasmu)-U0)*output_consu(j,cn,16)/1000 * (1-r)^(realtime(j,1)-2020); % utility of action in 2025, 2030, 2035 ...
                else
                    Us = 0; % utility of action in 2025, 2030, 2035 ...
                end
                output_util(mc,cn,s) = output_util(mc,cn,s) + Us;  % Sum of NPV of utility
            end
            Us = ((totalconsu(j,1,s)/totalconsu(j,1,16)*1000)^(1-elasmu)/(1-elasmu)-U0)*totalconsu(j,1,16)/1000 * (1-r)^(realtime(j,1)-2020);
            output_util(mc,cn_num+11,s) = output_util(mc,cn_num+11,s) + Us;  % Sum of NPV of utility
            j=j+1;
        end
    end
    for cn=1:(cn_num+11)
        for s=1:10
            A=zeros(1,5);
            A(1:5)=output_util(mc,cn,s:(s+4));
            [rs,ms,bs] = regression(t,A);
            output_util(mc,cn,s+14)=ms/(1-r*0.001)^(s*5); % dU/dt for mitigation in 2025, 2030, ..., 2070
        end
    end
    for cn=1:(cn_num+12)
        output_util(mc,cn,25:34) = output_temp(cn,1:10); % atmospheric temperature in 2025, 2030, ..., 2070 without mitigation
    end
    for cn=1:(cn_num+10)
        if output_consu(126,cn,15)>0
            output_util(mc,cn,35) = log(output_consu(136,cn,15)/output_consu(126,cn,15))/10; % Growth rate in consumption in 2025
        end
    end
    for s=1:10
        for cn=1:(cn_num+10)
            output_util(mc,cn,s+35) = output_consu(116+s*5,cn,15)/output_consu(116+s*5,cn,16)*1000; % per capital consumption in 2025, 2030, 2035 in BAU
            output_util(mc,cn,s+45) = output_consu(116+s*5,cn,16)/1000; % population in 2025, 2030, 2035 ...
        end
        output_util(mc,cn_num+11,s+35) = totalconsu(116+s*5,1,15)/totalconsu(116+s*5,1,16)*1000;
        output_util(mc,cn_num+11,s+45) = totalconsu(116+s*5,1,16)/1000;
    end
end
% x=mean(output_util(:,:,35),1); x2=x';
if simu==1
    save('..\output\MCobs_11_standard_output_util.dat','output_util');
elseif simu==2
    save('..\output\MCobs_21_noIEC_output_util.dat','output_util');
end

end
