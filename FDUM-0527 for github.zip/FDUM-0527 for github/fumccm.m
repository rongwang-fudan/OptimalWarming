% Author: Rong Wang // contact rongwang@fudan.edu.cn //
% Date: 2021.7.5
tic
clear;
clear global;

global  elas ESC INT FFlux

%Elasticity of substitution
elas = 0.4
%Equilibrium sensitivity of climate K Calderia, Contribution of Sea Ice Response to Climate Sensitivity, 2014
ESC = 1.05;
%Time inertia of climate system to reach equilibirum (year)
INT = 53;
%Climate damage function: dpo for power coefficient on temperature, dcoef for damage as a percentage of GDP for 1 degree warming
dpo = 2
%Data of climate damage: 1 (high damage, unconfirmed) 1999-Climate change policy_ quantifying uncertainties for damages and optimal carbon taxes; 2 (moderate, used by DICE) 2017-A Survey of Global Impacts of Climate Change: Replication, Survey Methods, and a Statistical Analysis
damagedata = 2;
%Learning rate on the cost curve
LR = 0.2;
%Peak population
LA = 11500;
%Year of COVID-19 outbreak
covidyear = 2020;
%year to initiate mitigation
abtyear = 2025;
%Ultimate fraction of CO2 emission abatement (1 for zero emissions)
abtfrac = 1;
%Time (years) to abate CO2 emissions
abtlen = 10;
% switcher for  C1	C2	S1	S2	S3	S4	S5	T1	T2	T3	T4
switcher = ones(1,10);
%Simulation output in scenarios
output_abt = zeros(396,22*3);

%Historical data of economy
Initialset;

%Historical data of climate
InitialsetC;

%Land-use change emissions GtC and radiative forcing for non-CO2
AerosolsLUC;

%Time series of population: L
L = population( LA );

%Calibration of climate damage function
[dcoef, xy_damage] = damage( dpo, damagedata );

%Calibration of induced efficiency change
[iec, output_iec, xy_iec] = Calibration_IEC( L );
% save('..\output\xy_iec.dat','xy_iec');

%Calibration of equilibrium sensitivity of climate
[output_esc] = Calibration_ESC( FFlux, 1 );

%Calibration of savings rate by capital, energy and ouput
[calrsav, output_cap] = Calibration_CAP( L, iec, dpo, dcoef, LR, switcher, 1 );

%Calibration of energy price during COVID-19
[oilprice1971_2019, oilprice2020_normalize, energyprice2020, SE, xy_price, co2emi_2019_2021] = energyprice( covidyear );

%Calibration of ENE reduction by COVID-19
[output_covid, deffs] = Calibration_COVID( FFlux, L, iec, calrsav, dpo, dcoef, LR, switcher, covidyear, 1 );

%Immediate CO2 abatement
S = Abatement( FFlux, L, iec, calrsav, dpo, dcoef, LR, covidyear, deffs, abtyear, abtfrac, abtlen, switcher );
output_abt(1:396,1:21)=S(1:396,1:21); output_abt(1:396,22)=S(1:396,31);

%Delayed CO2 abatement
S = Abatement( FFlux, L, iec, calrsav, dpo, dcoef, LR, covidyear, deffs, abtyear+25, abtfrac, abtlen, switcher );
output_abt(1:396,23:43)=S(1:396,1:21); output_abt(1:396,44)=S(1:396,31);

%No CO2 abatement
S = Abatement( FFlux, L, iec, calrsav, dpo, dcoef, LR, covidyear, deffs, abtyear, abtfrac, 200, switcher );
output_abt(1:396,45:65)=S(1:396,1:21); output_abt(1:396,66)=S(1:396,31);
gt=zeros(10,1);
for j=1:10
    gt(j,1) = log(S(131+j*5,7) / S(121+j*5,7) )/10; % growth rate in per capita consumption
end

%Experiments of factor attribution
S8A = Factor_Attri( FFlux, L, iec, calrsav, dpo, dcoef, LR, covidyear, deffs, 2025, abtfrac, 200, 1 );
S8B = Factor_Attri( FFlux, L, iec, calrsav, dpo, dcoef, LR, covidyear, deffs, 2025, abtfrac, abtlen, 1 );
S8 = S8B - S8A;
output_att = variableS8( S8, calrsav, L );

%Purpose of your simulation
Purpose=5;

%International cooperation
if Purpose==5
tempdiff=1; % 1 accounting for temperature different between countries (default); 2 not
iecone=1; % 1 applying the IEC by country (default); 2 applying the global IEC
negative_emissions=2; % 1 without negative emissions (default); 2 with negative emissions
singles=1; % 1 increasing number of countries for cooperation (default); 2 single country in cooperation
% NET=1548/3.6/250*0.358; % NET: the fraction of 100% negative emission energy in total new energy (‘most likely range’)   For IGCC plants, we adopted an electricity generation efﬁciency of 35.8% (Lu2019)
transtime=2025 % time needed in the transition of investment
translen=5 % time needed in the transition of investment
technology_diffusion=3 % 1 accounting for gloabl decline of zc energy cost due to learning-by-doing (default); 2 technology by country alone; 3 global technology diffusion; 4 regional technology diffusion
climate_economy=1 % 1 accounting for the impact of climate change on efficiencies (default); 2 not
enterseq=2 % sequence of entering the cooperation mechanism: 1 emission 2025; 2 GDP per capita 2025; 3 emission intensity
[output_gt, entercnid] = Model_cooperation( FFlux, L, iec, xy_iec, output_cap, dpo, dcoef, LR, covidyear, tempdiff, iecone, climate_economy, enterseq, technology_diffusion, transtime, translen, negative_emissions, singles);
end

% monte carlo
if Purpose==6
tempdiff=1; % 1 accounting for temperature different between countries (default); 2 not
iecone=1; % 1 applying the IEC by country (default); 2 applying the global IEC
negative_emissions=2; % 1 without negative emissions (default); 2 with negative emissions
singles=1; % 1 increasing number of countries for cooperation (default); 2 single country in cooperation
% NET=1548/3.6/250*0.358; % NET: the fraction of 100% negative emission energy in total new energy (‘most likely range’)   For IGCC plants, we adopted an electricity generation efﬁciency of 35.8% (Lu2019)
transtime=2025; % time needed in the transition of investment
translen=5; % time needed in the transition of investment
technology_diffusion=3; % 1 accounting for gloabl decline of zc energy cost due to learning-by-doing (default); 2 technology by country alone; 3 global technology diffusion; 4 regional technology diffusion
climate_economy=1; % 1 accounting for the impact of climate change on efficiencies (default); 2 not
enterseq=2; % sequence of entering the cooperation mechanism: 1 emission 2025-2125; 2 GDP per capita 2025; 3 utility benefit from mitigation
[output_gt] = MonteCarlo_cooperation( FFlux, L, iec, xy_iec, output_cap, dpo, dcoef, LR, covidyear, tempdiff, iecone, climate_economy, technology_diffusion, transtime, translen, negative_emissions, singles, 1, 2000);
end

% sensitivity test
if Purpose==7
tempdiff=1; % 1 accounting for temperature different between countries (default); 2 not
iecone=1; % 1 applying the IEC by country (default); 2 applying the global IEC
negative_emissions=2; % 1 without negative emissions (default); 2 with negative emissions
singles=1; % 1 increasing number of countries for cooperation (default); 2 single country in cooperation
% NET=1548/3.6/250*0.358; % NET: the fraction of 100% negative emission energy in total new energy (‘most likely range’)   For IGCC plants, we adopted an electricity generation efﬁciency of 35.8% (Lu2019)
transtime=2025; % time needed in the transition of investment
translen=5; % time needed in the transition of investment
technology_diffusion=3; % 1 accounting for gloabl decline of zc energy cost due to learning-by-doing (default); 2 technology by country alone; 3 global technology diffusion; 4 regional technology diffusion
climate_economy=1; % 1 accounting for the impact of climate change on efficiencies (default); 2 not
enterseq=2; % sequence of entering the cooperation mechanism: 1 emission 2025-2125; 2 GDP per capita 2025; 3 utility benefit from mitigation
[output_gt] = MonteCarlo_cooperation2( FFlux, L, iec, xy_iec, output_cap, dpo, dcoef, LR, covidyear, tempdiff, iecone, climate_economy, technology_diffusion, transtime, translen, negative_emissions, singles, 1, 198);
end

