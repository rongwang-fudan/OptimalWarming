% Author: Rong Wang // contact rongwang@fudan.edu.cn //
% Date: 2021.6.18

function [iec_cn, slopecn ] = IEC_cn( cndata, iec, xy_iec, plot_iec_cn )

% Economic variables cndata(KEYL)

% Economic variables econcn=zeros(49,23,i2+1)
% 1 EUE; 2 EPE; 3 ENE; 4 backstop price $/tCO2
% 5 abatement cost as a percentage of GDP; 6 climate damage as a percentage of GDP; 7 net output
% 8 fraction of labor allocation to energy; 9 fraction of investment allocation to energy
% 10 total capital (t$); 11 energy capital (t$); 12 energy (PJ); 13 output (t$); 14 energy price $/kWh; 15 omega
% 16 fraction of energy investment allocated to zero-carbon energy
% 17 energy capital carbon-emission-free (t$);
% 18 fraction to abate CO2 emission; 19 carbon price $/tCO2; 20 CO2 emissions Gt CO2; 21 green energy PJ; 22 invest change, 23 labor change

global alpha elas inputs cou_iform
%   alpha:  elasticity of output to capital
%   elas:   elasticity of substitution between energy and non-energy in output

cn_num=size(cndata,1);
omegas=(-1.52:0.01:-0.82); sn=size(omegas,2);
omegas2=(-0.071:0.001:-0.013); sn2=size(omegas2,2);

iec_cn=zeros(6,sn,cn_num);
xy_iec_cn=zeros(26,9,cn_num);

for cn=1:cn_num

iec_cn0=zeros(6,sn);
xy_iec_cn0=zeros(26,9);
lra=zeros(26,7);
for i=1:26
    x=[(1970+i):(1989+i)];
    y=inputs(i:(i+19),5); [sR,lr_pe0,bb0] = regression(x,log(y')); % energy price
    y=cndata(cn,(2*49-48+i):(2*49-48+i+19))./cndata(cn,(4*49-48+i):(4*49-48+i+19)); [sR,lr_e0,bb0] = regression(x,log(y)); % e=E/L
    y=cndata(cn,(3*49-48+i):(3*49-48+i+19))./cndata(cn,(4*49-48+i):(4*49-48+i+19)); [sR,lr_y0,bb0] = regression(x,log(y)); % y=Y/L
    y=cndata(cn,(1*49-48+i):(1*49-48+i+19))./cndata(cn,(4*49-48+i):(4*49-48+i+19)); [sR,lr_k0,bb0] = regression(x,log(y)); % k=K/L    
    y=inputs(i:(i+19),6) .* (cndata(cn,(2*49-48+i):(2*49-48+i+19))./cndata(cn,(3*49-48+i):(3*49-48+i+19))) ./ (inputs(i:(i+19),1).*3600./inputs(i:(i+19),3)); % omega
    avef0=mean(y,1); startf0=y(1);
    lr_se0 = lr_pe0 + lr_e0 - lr_y0;
    lr_B = lr_e0 - alpha*lr_k0;
    lr_A = lr_y0 - alpha*lr_k0;
    lr_taue0 = elas/(elas-1)*lr_se0 - lr_e0 + lr_y0;
    lr_we0 = lr_B - lr_se0;
    lr_b0 = (lr_A - avef0*(lr_we0 + lr_taue0))/(1-avef0);
    lra(i,1) = startf0;
    lra(i,2) = lr_taue0;
    lra(i,3) = lr_we0;
    lra(i,4) = max(0.0001,lr_b0);
    lra(i,5) = 0; % damage of climate change
    lra(i,6) = lra(i,1);
    lra(i,7) = 1-lra(i,1);
    lra(i,8) = lr_se0;
end
xy_iec_cn0(:,1)=lra(:,2); % eue rate
xy_iec_cn0(:,2)=lra(:,3); % epe rate
xy_iec_cn0(:,3)=lra(:,4); % ene rate
xy_iec_cn0(:,4)=lra(:,6); % omega
xy_iec_cn0(:,5)=lra(:,7); % 1 - omega
xy_iec_cn0(:,9)=lra(:,8); % omega rate

% omegathreshold=prctile(lra(:,7),[25]);
% idx1=find(lra(:,7)<=omegathreshold);
% idx2=find(lra(:,7)>omegathreshold);
idx1=find(lra(:,7)<0.93);
idx2=find(lra(:,7)>0.92);
if size(idx1,1)<5 || size(idx2,1)<5
    idx1=find(lra(:,7)>0);
    idx2=find(lra(:,7)>0);
end

% EUE
x=log10(lra(:,6)); y=lra(:,2);
a=polyfit(x,y,1);
iec_cn0(1,1:sn)=polyval(a,omegas);
xy_iec_cn0(:,6)=polyval(a,x);
[R,P] = corrcoef(x,y);
if R(1,2)<0.5
    iec_cn0(1,1:sn)=iec(1,1:sn);
end

% EPE
y=lra(:,3);
a=polyfit(x,y,1);
iec_cn0(2,:)=polyval(a,omegas);
xy_iec_cn0(:,7)=polyval(a,x);
[R,P] = corrcoef(x,y);
if R(1,2)<0.5
    iec_cn0(2,1:sn)=iec(2,1:sn);
end

% ENE - omega
x=log10(lra(idx1,6)); y=lra(idx1,4);
a=polyfit(x,y,1);
a1=polyval(a,omegas);
x=log10(lra(idx2,6)); y=lra(idx2,4);
a=polyfit(x,y,1);
a2=max(a1,polyval(a,omegas));
iec_cn0(3,1:sn)=max(a1,a2);

% ENE - 1-omega
x=log10(lra(idx1,7)); y=lra(idx1,4);
a=polyfit(x,y,1);
a1=polyval(a,omegas2);
xy_iec_cn0(:,8)=polyval(a,log10(lra(:,7)));
[R1,P1] = corrcoef(x,y);

x=log10(lra(idx2,7)); y=lra(idx2,4);
a=polyfit(x,y,1);
a2=polyval(a,omegas2);
iec_cn0(4,1:sn2)=max(a1,a2);
xy_iec_cn0(:,8)=max(xy_iec_cn0(:,8),polyval(a,log10(lra(:,7))));
[R2,P2] = corrcoef(x,y);
if R1(1,2)<0.5 || R2(1,2)<0.5
    iec_cn0(4,1:sn2)=iec(4,1:sn2);
end

iec_cn0(5,:)=omegas;
iec_cn0(6,1:sn2)=omegas2;

iec_cn(:,:,cn)=iec_cn0;
xy_iec_cn(:,:,cn)=xy_iec_cn0;

end

slopecn=zeros(cn_num,9);
for cn=1:cn_num
    slopecn(cn,1)=(xy_iec_cn(4,6,cn)-xy_iec_cn(1,6,cn))/(log(xy_iec_cn(4,4,cn))-log(xy_iec_cn(1,4,cn))); % eue slope
    slopecn(cn,2)=(xy_iec_cn(4,7,cn)-xy_iec_cn(1,7,cn))/(log(xy_iec_cn(4,4,cn))-log(xy_iec_cn(1,4,cn))); % epe slope
    slopecn(cn,3)=(xy_iec_cn(4,8,cn)-xy_iec_cn(1,8,cn))/(log(xy_iec_cn(4,5,cn))-log(xy_iec_cn(1,5,cn))); % ene slope
    
    slopecn(cn,4)=(iec_cn(1,4,cn)-iec_cn(1,1,cn))/(log(10^iec_cn(5,4))-log(10^iec_cn(5,1)));
    slopecn(cn,5)=(iec_cn(2,4,cn)-iec_cn(2,1,cn))/(log(10^iec_cn(5,4))-log(10^iec_cn(5,1)));
    slopecn(cn,6)=(iec_cn(4,4,cn)-iec_cn(4,1,cn))/(log(10^iec_cn(6,4))-log(10^iec_cn(6,1)));
    
    slopecn(cn,7) = mean(xy_iec_cn(:,1,cn),1);
    slopecn(cn,8) = mean(xy_iec_cn(:,2,cn),1);
    slopecn(cn,9) = mean(xy_iec_cn(:,3,cn),1);
end

if plot_iec_cn==1    
    % EUE rates as a function of log10(Omega)
    subplot(2,3,1); 
    for cn=2:cn_num
        if cou_iform(cndata(cn,1),2)==1 % developed countries
            x=log10(xy_iec_cn(:,4,cn)); y=xy_iec_cn(:,1,cn); a=polyfit(x,y,1); y2=polyval(a,omegas);
            plot(x,y,'o','MarkerEdgeColor','none','MarkerFaceColor',[0.7 0.7 0.7],'MarkerSize',1); hold on;
            plot(omegas,y2,'LineStyle','-','LineWidth',0.1,'Color',[0.4 0.8 1]); hold on;
        else % developing countries
            x=log10(xy_iec_cn(:,4,cn)); y=xy_iec_cn(:,1,cn); a=polyfit(x,y,1); y2=polyval(a,omegas);
            plot(x,y,'o','MarkerEdgeColor','none','MarkerFaceColor',[1 0.6 0.6],'MarkerSize',1); hold on;
            plot(omegas,y2,'LineStyle','-','LineWidth',0.1,'Color',[1 0.8 0.4]); hold on;
        end
    end
    plot(iec(5,1:71),iec(1,1:71),'LineStyle','-','LineWidth',2,'Color',[0 0 0]); hold on;
    axis([-1.8 -0.6 -0.1 0.1]);
    
    subplot(2,3,4);
    plot(log10(xy_iec(:,4)),xy_iec(:,1),'o','MarkerEdgeColor',[0 0 0],'MarkerFaceColor','none','MarkerSize',3); hold on;
    plot(iec(5,1:71),iec(1,1:71),'LineStyle','--','LineWidth',2,'Color',[0.8 0 0]); hold on;
    axis([-1.8 -0.6 -0.1 0.1]);
    
    % EPE rates as a function of log10(Omega)
    subplot(2,3,2); 
    for cn=2:cn_num
        if cou_iform(cndata(cn,1),2)==1 % developed countries
            x=log10(xy_iec_cn(:,4,cn)); y=xy_iec_cn(:,2,cn); a=polyfit(x,y,1); y2=polyval(a,omegas);
            plot(x,y,'o','MarkerEdgeColor','none','MarkerFaceColor',[0.7 0.7 0.7],'MarkerSize',1); hold on;
            plot(omegas,y2,'LineStyle','-','LineWidth',0.1,'Color',[0.4 0.8 1]); hold on;
        else % developing countries
            x=log10(xy_iec_cn(:,4,cn)); y=xy_iec_cn(:,2,cn); a=polyfit(x,y,1); y2=polyval(a,omegas);
            plot(x,y,'o','MarkerEdgeColor','none','MarkerFaceColor',[1 0.6 0.6],'MarkerSize',1); hold on;
            plot(omegas,y2,'LineStyle','-','LineWidth',0.1,'Color',[1 0.8 0.4]); hold on;
        end
    end
    plot(iec(5,1:71),iec(2,1:71),'LineStyle','-','LineWidth',2,'Color',[0 0 0]); hold on;
    axis([-1.8 -0.6 -0.1 0.1]);
    
    subplot(2,3,5);
    plot(log10(xy_iec(:,4)),xy_iec(:,2),'o','MarkerEdgeColor',[0 0 0],'MarkerFaceColor','none','MarkerSize',3); hold on;
    plot(iec(5,1:71),iec(2,1:71),'LineStyle','--','LineWidth',2,'Color',[0.8 0 0]); hold on;
    axis([-1.8 -0.6 -0.1 0.1]);
    
    % ENE rates as a function of log10(1-Omega)
    subplot(2,3,3); 
    for cn=2:cn_num
        if cou_iform(cndata(cn,1),2)==1 % developed countries
            x=log10(xy_iec_cn(:,5,cn)); y=xy_iec_cn(:,3,cn); a=polyfit(x,y,1); y2=polyval(a,omegas2);
            plot(x,y,'o','MarkerEdgeColor','none','MarkerFaceColor',[0.7 0.7 0.7],'MarkerSize',1); hold on;
            plot(omegas2,y2,'LineStyle','-','LineWidth',0.1,'Color',[0.4 0.8 1]); hold on;
        else % developing countries
            x=log10(xy_iec_cn(:,5,cn)); y=xy_iec_cn(:,3,cn); a=polyfit(x,y,1); y2=polyval(a,omegas2);
            plot(x,y,'o','MarkerEdgeColor','none','MarkerFaceColor',[1 0.6 0.6],'MarkerSize',1); hold on;
            plot(omegas2,y2,'LineStyle','-','LineWidth',0.1,'Color',[1 0.8 0.4]); hold on;
        end
    end
    plot(iec(6,1:59),iec(4,1:59),'LineStyle','-','LineWidth',2,'Color',[0 0 0]); hold on;    
    axis([-0.08 -0.01 0 0.05]);
    
    subplot(2,3,6);
    plot(log10(xy_iec(:,5)),xy_iec(:,3),'o','MarkerEdgeColor',[0 0 0],'MarkerFaceColor','none','MarkerSize',3); hold on;
    plot(iec(6,1:59),iec(4,1:59),'LineStyle','--','LineWidth',2,'Color',[0.8 0 0]); hold on;
    axis([-0.08 -0.01 0 0.05]);
end

eue0 = mean(xy_iec(:,1),1);
epe0 = mean(xy_iec(:,2),1);
ene0 = mean(xy_iec(:,3),1);

for cn=1:cn_num    
    % Extreme values lead to extremes of the prediction of gdp
    if iec_cn(1,1,cn)>0.05 || iec_cn(1,1,cn)<-0.05
        iec_cn(1,1:sn,cn)=iec(1,1:sn);
        slopecn(cn,7) = eue0;
    end
    if iec_cn(2,1,cn)>0.05 || iec_cn(2,1,cn)<-0.1
        iec_cn(2,1:sn,cn)=iec(2,1:sn);
        slopecn(cn,8) = epe0;
    end
    if iec_cn(4,1,cn)>0.03 || iec_cn(4,1,cn)<0
        iec_cn(4,1:sn2,cn)=iec(4,1:sn2);
        slopecn(cn,9) = ene0;
    end
    for j=1:sn
        iec_cn(1,j,cn)=min(0.1001,max(-0.1001,iec_cn(1,j,cn)));
        iec_cn(2,j,cn)=min(0.1001,max(-0.1001,iec_cn(2,j,cn)));
        slopecn(cn,7)=min(0.1001,max(-0.1001,slopecn(cn,7)));
        slopecn(cn,8)=min(0.1001,max(-0.1001,slopecn(cn,8)));
    end
    for j=1:sn2
        iec_cn(4,j,cn)=min(0.0501,max(0.0001,iec_cn(4,j,cn)));
        slopecn(cn,9)=min(0.0501,max(0.0001,slopecn(cn,9)));
    end    
    if mean(iec_cn(1,1:sn,cn)-iec(1,1:sn),2)>0.01
        iec_cn(1,1:sn,cn)=iec(1,1:sn);
        slopecn(cn,7) = eue0;
    end
    if mean(iec_cn(2,1:sn,cn)-iec(2,1:sn),2)>0.02
        iec_cn(2,1:sn,cn)=iec(2,1:sn);
        slopecn(cn,8) = epe0;
    end
    if mean(iec_cn(4,1:sn2,cn)-iec(4,1:sn2),2)>0.005
        iec_cn(4,1:sn2,cn)=iec(4,1:sn2);
        slopecn(cn,9) = ene0;
    end
end

% IEC is less reliable to apply for small countries, where GDP is observed
% to increase unreasonably from 2020 to 2100. National IEC is adopted for
% these countries.

iec_cn(:,:,9)=iec; slopecn(9,7:9) = [eue0 epe0 ene0];
iec_cn(:,:,10)=iec; slopecn(10,7:9) = [eue0 epe0 ene0];
iec_cn(:,:,11)=iec; slopecn(11,7:9) = [eue0 epe0 ene0];
iec_cn(:,:,59)=iec; slopecn(59,7:9) = [eue0 epe0 ene0];
iec_cn(:,:,81)=iec; slopecn(81,7:9) = [eue0 epe0 ene0];
iec_cn(:,:,84)=iec; slopecn(84,7:9) = [eue0 epe0 ene0];
iec_cn(:,:,87)=iec; slopecn(87,7:9) = [eue0 epe0 ene0];
iec_cn(:,:,93)=iec; slopecn(93,7:9) = [eue0 epe0 ene0];
iec_cn(:,:,99)=iec; slopecn(99,7:9) = [eue0 epe0 ene0];

end

%Regression coefficient
% k_EUE = 0.1357; % coefficient for EUE (slope to energy cost share)
% b_EUE = 0.1717; % coefficient for EUE (offset)
% k_EPE = 0.1985; % coefficient for EPE (slope to energy cost share)
% b_EPE = 0.2256; % coefficient for EPE (offset)
% k_ENE = -0.013; % coefficient for ENE (slope to energy cost share)
% b_ENE = - k_ENE * log10(0.1) + ENErate(Ts1,1); % coefficient for ENE (offset)


