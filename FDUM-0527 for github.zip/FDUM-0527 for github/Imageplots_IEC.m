% Author: Rong Wang // contact rongwang@fudan.edu.cn //
% Date: 2021.7. 29

% Plot of efficiency rates against omega

function Imageplots_IEC ( xy_iec )

figure(1);
subplot(2,2,1);
plot(log10(xy_iec(:,4)),xy_iec(:,1),'o','MarkerEdgeColor',[1,0,0]); hold on;
a=polyfit(log10(xy_iec(:,4)),xy_iec(:,1),1);
xi=(min(log10(xy_iec(:,4)),[],1)-0.001):0.001:(max(log10(xy_iec(:,4)),[],1)+0.001);
yi=polyval(a,xi);
plot(xi,yi,'linewidth',2)
title('EUE-omega Plot')
xlabel('log10(omega)')
ylabel('EUE rate')
% legend('data','fitting')
text(-1.12,0.01,strcat('Y=',num2str(a(1)),'X+',num2str(a(2))),'FontSize',8);

subplot(2,2,2);
plot(log10(xy_iec(:,4)),xy_iec(:,2),'o','MarkerEdgeColor',[1,0,0]); hold on;
a=polyfit(log10(xy_iec(:,4)),xy_iec(:,2),1);
xi=(min(log10(xy_iec(:,4)),[],1)-0.001):0.001:(max(log10(xy_iec(:,4)),[],1)+0.001);
yi=polyval(a,xi);
plot(xi,yi,'linewidth',2)
title('EPE-omega Plot')
xlabel('log10(omega)')
ylabel('EPE rate')
text(-1.12,-0.03,strcat('Y=',num2str(a(1)),'X+',num2str(a(2))),'FontSize',8);

subplot(2,2,3);
plot(log10(xy_iec(:,4)),xy_iec(:,3),'o','MarkerEdgeColor',[1,0,0]); hold on;
a=polyfit(log10(xy_iec(:,4)),xy_iec(:,3),1);
xi=(min(log10(xy_iec(:,4)),[],1)-0.001):0.001:(max(log10(xy_iec(:,4)),[],1)+0.001);
yi=polyval(a,xi);
plot(xi,yi,'linewidth',2)
title('ENE-omega Plot')
xlabel('log10(omega)')
ylabel('ENE rate')
text(-1.15,0.01,strcat('Y=',num2str(a(1)),'X+',num2str(a(2))),'FontSize',8);

subplot(2,2,4);
idx=find(xy_iec(:,5)<0.93);
plot(log10(xy_iec(idx,5)),xy_iec(idx,3),'o','MarkerEdgeColor',[0,0,0]); hold on;
a=polyfit(log10(xy_iec(idx,5)),xy_iec(idx,3),1);
xi=(min(log10(xy_iec(idx,5)),[],1)-0.001):0.001:(max(log10(xy_iec(idx,5)),[],1)+0.001);
yi=polyval(a,xi);
plot(xi,yi,'linewidth',2,'Color',[0,0,0]); hold on;
text(-0.048,0.006,strcat('Y=',num2str(a(1)),'X+',num2str(a(2))),'FontSize',8);
idx=find(xy_iec(:,5)>0.92);
plot(log10(xy_iec(idx,5)),xy_iec(idx,3),'o','MarkerEdgeColor',[1,0,0]); hold on;
a=polyfit(log10(xy_iec(idx,5)),xy_iec(idx,3),1);
xi=(min(log10(xy_iec(idx,5)),[],1)-0.001):0.001:(max(log10(xy_iec(idx,5)),[],1)+0.001);
yi=polyval(a,xi);
plot(xi,yi,'linewidth',2,'Color',[1,0,0])
text(-0.045,0.01,strcat('Y=',num2str(a(1)),'X+',num2str(a(2))),'FontSize',8,'Color',[1,0,0]);
title('ENE-omega Plot')
xlabel('log10(1-omega)')
ylabel('ENE rate')

end