% Author: Rong Wang // contact rongwang@fudan.edu.cn //
% Date: 2021.12.20
tic
clear;

realtime = xlsread('files\time.xlsx');
realtime(:,1) = realtime(:,1) + 0.00001;

tempinput = load('files\temperature.txt'); % 764x12 (1 globe; 2-11 for region; 12 for ocean)
tempvar=zeros(20,12);
tempinputyy=zeros(63,12);
for yy=1:63
    tempinputyy(yy,1:12)=mean(tempinput((yy*12-11):(yy*12),1:12),1);
end
for ts=1:20
    tempinput2=zeros(64-ts,12);
    % moving ave
    for s=1:ts
        tempinput2=tempinput2+tempinputyy(s:(63-ts+s),:);
    end
    tempinput2=tempinput2./ts;
    tempvar(ts,1:12) = std(detrend(tempinput2),[],1);
end

load('files\cndata.dat','-mat');
cndata=cndata2; clear cndata2;
cn_num=size(cndata,1)+10;  % 1 globe; 2 globe; 3-114 by country; 115-123 for 9 zone

num1=11; % 21 for 0, 5, 10, ..., 100 percentiles; 11 for 0, 10, 20, ..., 100 percentiles
num2=18; % number of parameters
num3=num1*num2;
nmc=10000+num3;
% nmc=num3;
elasmu=1.45; % elasticity of marginal utility of consumption
elasmu2=1-elasmu;
idr=0.048; % intergenerational discount rate in 2025
rou=idr-1.45*0.016; % social time preference of consumption

load('..\output\MCobs_11_standard_output_util.dat','-mat'); % x=mean(output_util(:,:,35),1); x2=x';
% 1 globe; 2 globe; 3-114 by country; 115-123 for 9 zone; 124 for sum of countries
% 1 N Ame; 2 S Ame; 3 W Eur; 4 N Afr & Middle East; 5 S Afr; 6 Russia; 7 E Asia; 8 S & SE Asia; 9 Oceania; 10 Polar; 11 Ocean
% 1-14 Utotal; 15-24  dU/dt; 25-34 temperature for 125 regions in 2025, 2030, 2035 ... 2070
% 35 rate of consumption growth in 2030
% 36-45 per capital consumption in 2025, 2030, 2035 ... 2070
% 46-55 population in 2025, 2030, 2035 ... 2070

% xx=randn(100000,1);
% xra=prctile(xx,[0:1:100],1); % du/ds by year
% xra=[-1.96000000000000;-1.64813271378742;-1.28613372071428;-1.03696234321609;-0.844492884450751;-0.676925320813962;-0.527894367333415;-0.402920558568819;-0.265930233109539;-0.149229844668551;-0.0205257114860915;0.113957817061441;0.242432349790607;0.376949571488937;0.508044017944601;0.658551851844843;0.833469925620126;1.03016998482561;1.28025683193193;1.63438823247971;1.96000000000000];
% xra(1)=-100;
% xra(end)=100;
% save('files\xra.dat','xra');
load('files\xra.dat','-mat');

wop=zeros(10,30);
wopdist=zeros(100,24);
tom=zeros(10,1+30);
regionofpay=1; % 1 globe; 2 globe; 3-114 by country; 115-123 for 9 zone; 124 for sum of countries
proba=0.66;

timeobs=6; % timing of observations: 1 for 2025; 2 for 2030; 3 for 2035; 4 for 2040; 5 for 2045, 6 for 2050; 7 for 2055; 8 for 2060; 9 for 2065; 10 for 2070
zobs=11; % region of observation: 1 N Ame; 2 S Ame; 3 W Eur; 4 N Afr & Middle East; 5 S Afr; 6 Russia; 7 E Asia; 8 S & SE Asia; 9 Oceania; 10 Polar; 11 Ocean
typeobs=95; % percentile of obs; 95 for observation of a 95% high temperature; 5 for observation of a 5% low temperature
len=5; % length of observation

% Cases with observations
tempdist=ones(nmc,1);
x1=output_util(:,cn_num+zobs-11,24+timeobs); % temperature in the model
x2=prctile(x1,typeobs); % 5% percentile
x=(x1-x2)./tempvar(len,zobs+1);
for k=50:-1:1
    idx=find( x<xra(k) | x>xra(102-k) );
    tempdist(idx,1)=(k-1)/50; % probability of a temperature
    if k==2
        for mc=1:size(idx,1)
            tempdist(mc,1)=max(0,0.02-(abs(x(idx(mc)))-xra(100))/(5-xra(100))*0.02);
        end
    end
end

% Case of no observations
s0=10;
for s=timeobs:10
    idx=find(output_util(:,regionofpay,s+14)<0);    
    if (size(idx,1)/nmc)>proba
        % action
        s0=s; break;
    end
end

% Cases with observations
s02=10;
for s=timeobs:10
    idx=find(output_util(:,regionofpay,s+14)<0);
    prob=sum(tempdist(idx,1),1)/sum(tempdist(:,1),1);
    if prob>proba
        s02=s; break; % action if the probability of du/dt<0 is >67%
    end
end

wopmc=zeros(nmc,1);
for mc=1:nmc
    deltaU=(output_util(mc,regionofpay,s02)-output_util(mc,regionofpay,s0))/(1-rou*0.001)^(timeobs*5);
    deltaU=deltaU/output_util(mc,regionofpay,timeobs+45)*elasmu2;
    deltaU=1-deltaU/(output_util(mc,regionofpay,timeobs+35)^elasmu2);
    if deltaU>0
        xrou=1-exp(log(deltaU)/elasmu2);
    else
        xrou=-1;
    end
    wopmc(mc,1)=xrou; % willingness of payment
end

subplot(2,2,1);
t1=min(x1,[],1);
t2=max(x1,[],1);
ti=0.04;
tn=floor((t2-t1)/ti)+1;
pdf_temp=zeros(tn,2);
pdf_tempxx=[t1:ti:(t1+ti*(tn-1))];
for mc=1:nmc
    pdf_temp(floor((x1(mc)-t1)/ti)+1,1)=pdf_temp(floor((x1(mc)-t1)/ti)+1,1)+1; % probabality density
    pdf_temp(floor((x1(mc)-t1)/ti)+1,2)=pdf_temp(floor((x1(mc)-t1)/ti)+1,2)+tempdist(mc); % probabality density
end
pdf_temp(:,1)=pdf_temp(:,1)./(sum(pdf_temp(:,1),1)*ti);
pdf_temp(:,2)=pdf_temp(:,2)./(sum(pdf_temp(:,2),1)*ti);
bar(pdf_tempxx,pdf_temp);

subplot(2,2,2);
x1=output_util(:,regionofpay,6+14); % time of decision: 1 for 2025; 2 for 2030; 3 for 2035; 4 for 2040; 5 for 2045, 6 for 2050; 7 for 2055; 8 for 2060; 9 for 2065; 10 for 2070
t1=min(x1,[],1);
t2=max(x1,[],1);
ti=0.005;
tn=floor((t2-t1)/ti)+1;
pdf_temp=zeros(tn,2);
pdf_tempxx=[t1:ti:(t1+ti*(tn-1))];
for mc=1:nmc
    pdf_temp(floor((x1(mc)-t1)/ti)+1,1)=pdf_temp(floor((x1(mc)-t1)/ti)+1,1)+1; % probabality density
    pdf_temp(floor((x1(mc)-t1)/ti)+1,2)=pdf_temp(floor((x1(mc)-t1)/ti)+1,2)+tempdist(mc); % probabality density
end
pdf_temp(:,1)=pdf_temp(:,1)./(sum(pdf_temp(:,1),1)*ti);
pdf_temp(:,2)=pdf_temp(:,2)./(sum(pdf_temp(:,2),1)*ti);
bar(pdf_tempxx,pdf_temp);

% Change of the probability of mitigation
subplot(2,2,3);
prob_mit=zeros(10,2);
for s=1:10
    idx=find(output_util(:,regionofpay,s+14)<0);
    prob_mit(s,1)=size(idx,1)/nmc;
    prob_mit(s,2)=sum(tempdist(idx,1),1)/sum(tempdist(:,1),1);
end
plot(prob_mit);

subplot(2,2,4);
x1=wopmc;
t1=min(x1,[],1);
t2=max(x1,[],1);
ti=0.012;
tn=floor((t2-t1)/ti)+1;
pdf_temp=zeros(tn,1);
pdf_tempxx=[t1:ti:(t1+ti*(tn-1))];
for mc=1:nmc
    pdf_temp(floor((x1(mc)-t1)/ti)+1,1)=pdf_temp(floor((x1(mc)-t1)/ti)+1,1)+tempdist(mc); % probabality density
end
pdf_temp(:,1)=pdf_temp(:,1)./(sum(pdf_temp(:,1),1)*ti);
bar(pdf_tempxx,pdf_temp);




