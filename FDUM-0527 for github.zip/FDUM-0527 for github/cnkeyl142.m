tic
clear;

clear global;

%Elasticity of substitution
elas = 0.4;
%Equilibrium sensitivity of climate K Calderia, Contribution of Sea Ice Response to Climate Sensitivity, 2014
ESC = 1.05;
%Time inertia of climate system to reach equilibirum (year)
INT = 53;
%Climate damage function: dpo for power coefficient on temperature, dcoef for damage as a percentage of GDP for 1 degree warming
dpo = 2;
%Data of climate damage: 1 (high damage, unconfirmed) 1999-Climate change policy_ quantifying uncertainties for damages and optimal carbon taxes; 2 (moderate, used by DICE) 2017-A Survey of Global Impacts of Climate Change: Replication, Survey Methods, and a Statistical Analysis
damagedata = 2;
%Learning rate on the cost curve
LR = 0.2;
%Peak population
LA = 11500;
%Year of COVID-19 outbreak
covidyear = 2020;
%year to initiate mitigation
abtyear = 2025;
%Ultimate fraction of CO2 emission abatement (1 for zero emissions)
abtfrac = 1;
%Time (years) to abate CO2 emissions
abtlen = 10;
% switcher for  C1	C2	S1	S2	S3	S4	S5	T1	T2	T3	T4
switcher = ones(1,10);
%Simulation output in scenarios
output_abt = zeros(396,22*3);

%Historical data of economy
Initialset;

%Historical data of climate
InitialsetC;

%Land-use change emissions GtC and radiative forcing for non-CO2
AerosolsLUC;

%Time series of population: L
L = population( LA );

%Calibration of climate damage function
[dcoef, xy_damage] = damage( dpo, damagedata );

%Calibration of induced efficiency change
[iec, output_iec, xy_iec] = Calibration_IEC( L );
% save('..\output\xy_iec.dat','xy_iec');

%Calibration of equilibrium sensitivity of climate
[output_esc] = Calibration_ESC( FFlux, 1 );

%Calibration of savings rate by capital, energy and ouput
[calrsav, output_cap] = Calibration_CAP( L, iec, dpo, dcoef, LR, switcher, 1 );


erate=zeros(45,5);
for i=1:45
    i1=max(1,i-2); i2=min(45,i+2);
    x=realtime(i1:i2,1);
    for j=1:5
        if j<5
            y=log(output_cap(i1:i2,26+j)); % K, E, Y, L
        elseif j==5
            y=log(output_cap(i1:i2,28).*Egreen(i1:i2,8)); % Zero-carbon energy
        end
        [r,m,b]=regression(x',y');
        erate(i,j)=m;
    end
end

%National data
cnK = load('files\cnK.txt'); % 175x71 (1971-2019) repeat China
cnE = load('files\cnE.txt'); % 142x50 (1971-2019) repeat China
cnY = load('files\cnY.txt');
cnL = load('files\cnL.txt');
cnP1 = load('files\cnE_total.txt'); % 215x40 (1980-2018) repeat China/US
cnP2 = load('files\cnE_nuclear.txt');
cnP3 = load('files\cnE_renew.txt');
cndata=zeros(142,1+49*5); % KEYL+Ez
i2=0;
for i=1:142
    if i==24 || i==26
        continue;
    end
    for s=1:5
        if s==1
            idk=0;
            for ik=1:175
                if cnK(ik,1)==cnE(i,1) && ik~=38 && ik~=39 && ik~=40 % repeated country
                    x=cnK(ik,23:71);
                    idk=ik; % we get country ID in cnK the same as that in cnE
                end
            end
            if idk==0
                break; % no country ID in cnK is the same as that in cnE
            end
        elseif s==2
            x=cnE(i,2:50);
        elseif s==3
            x=cnY(i,2:50);
        elseif s==4
            x=cnL(i,2:50);
        elseif s==5
            % energy by carbon-zero
            idk=0;
            for ik=1:215
                if cnP1(ik,1)==cnE(i,1) && ik~=41 && ik~=42 && ik~=43 && ik~=203 && ik~=204 && ik~=205 % repeated country
                    x=zeros(1,49);
                    for j=1:49
                        j2=min(40,max(j-8,2));
                        if cnP1(ik,j2)>0 && (cnP2(ik,j2)+cnP3(ik,j2))>0
                            idk=ik;
                            x(j)=(cnP2(ik,j2)+cnP3(ik,j2))/cnP1(ik,j2)*cndata(i2,2*49-48+j);
                        else
                            x(j)=-999;
                        end
                    end
                end
            end
            if idk==0
                for j=1:49
                    cndata(i2,s*49-48+j)=Egreen(min(j,45),8)*cndata(i2,2*49-48+j);
                end
                continue;
            end
        end
        % find the longest time series
        len=zeros(49,1);
        for j=1:49
            for k=1:(50-j)
                if x(j+k-1)>0
                    len(j)=len(j)+1;
                else
                    break;
                end
            end
        end
        [IB, IX] = sort(len, 1); % rank of per capita GDP
        if IB(end)<10 && s~=5
            if s>1
                i2=i2-1; % erase this country from the list
            end
            break;
        end
        if s==1
            i2=i2+1; % add this country to the list
            cndata(i2,1)=cnE(i,1);
        end
        % fill in missing data
        if IX(end)>1
            for j=(IX(end)-1):-1:1
                x(j)=x(j+1)/(1+erate(min(45,j),s));
            end
        end
        if (IX(end)+IB(end)-1)<49
            for j=(IX(end)+IB(end)):49
                x(j)=x(j-1)/(1+erate(min(45,j),s));
            end
        end
        cndata(i2,(s*49-47):(s*49+1))=x(1,1:49);
    end
end
cndata=cndata(1:(i2+1),1:end);

% calibration by the global data
cndata(i2+1,1:end)=sum(cndata(1:i2,:),1);
for s=1:5
    for j=1:49
        if j<=45
            if s==5
                ratio=output_cap(j,28)*Egreen(j,8)/cndata(i2+1,s*49-48+j);
            else
                ratio=output_cap(j,26+s)/cndata(i2+1,s*49-48+j);
            end
            if s==2 || s==5
                ratio=ratio * 3600; % energy PWh -> PJ
            end
        end
        cndata(1:i2,s*49-48+j)=cndata(1:i2,s*49-48+j).*ratio;
    end
end
cndata(i2+1,1:end)=sum(cndata(1:i2,:),1);
cndata(i2+1,1)=0; % global
cndata2=cndata;
cndata2(1,:)=cndata(i2+1,:); % KEYLG
cndata2(2:(i2+1),:)=cndata(1:i2,:);

save('files\cndata134.dat','cndata2');

