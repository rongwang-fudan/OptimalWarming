% Author: Rong Wang // contact rongwang@fudan.edu.cn //
% Date: 2021.12.20
% Assessing the contribution of different parameters to the uncertainty
% 1	Slope of regional temperature to global temperature lamba_region	-
% 2	Equilibrium sensitivity of climate	ESC	K/(W/m2)
% 3	Inertia of atmospheric surface temperature	INT	yr
% 4	Industrial CO2 emissions	indemi	-
% 5	LUC emissions	lucemi	-
% 6	C flux from air to terrestrial biosphere	Flux14	GtC/yr
% 7	C flux from air to surface ocean	Flux15	GtC/yr
% 8	C flux from terrestrial biosphere to soil	Flux42	GtC/yr
% 9	Turnover time of C in soil	LTsoil	yr
% 10	Turnover time of C in deep ocean	LTocean	yr
% 11	Radiative forcing of methan	rf_ch4	-
% 12	Radiative forcing of nitrogen oxide	rf_n2o	-
% 13	Radiative forcing of CFCs	rf_cfc	-
% 14	Radiative forcing of aerosols	rf_aer	-
% 15	Elasticity of substitution between energy and non-energy inputs	elas	-
% 16	Sensitivity of induced EUE change rate to the share of energy expenditure in total costs	ss_eue	-
% 17	Economic damage of 1C warming	dcoef	-
% 18	Learning rate	LR	-

function [ output_gt ] = MonteCarlo_cooperation2( FFlux, L, iec, xy_iec, output_cap, dpo, dcoef, LR, covidyear, tempdiff, iecone, climate_efficiency, technology_diffusion, transtime, translen, negative_emissions, singles, ss1, ss2 )

unc=[1	1	2	4	4	1	1	1	3	3	4	4	4	4	1	4	4	2
0.00267	1.05	53	1	1	50.3	48.5	39.1	70.71067812	447.2135955	1	1	1	1	0.4	1	1	0.2
0.000418112	0.265306122	10	0.05	0.1	5	5	5	0.433410715	0.331895407	0.1	0.1	0.1	0.5	0.2	0.11	0.23	0.1
0.000418112	0.198979592	10	0.05	0.1	5	5	5	0.433410715	0.331895407	0.1	0.1	0.1	0.5	0.2	0.11	0.23	0.2];

global  alpha elas theta2 econo0 clim0 EFco2 Egreen Fex Eland realtime carbonbudget20 cndata cou_iform

% nmc=10000;
num1=11; % 11 for 0, 10, 20, ..., 100 percentiles
num2=18; % number of parameters
num3=num1*num2;
cn_num=size(cndata,1);
% para_range = zeros(num2,num1); % range of parameters

EFco20=EFco2;
carbonbudget20s=carbonbudget20;
Eland0 = Eland;
Fex0=Fex;
dcoef0=dcoef;
FFlux0=FFlux;
LR0=LR;
elas0=max(0.02,elas);

%Input of data by country: cndata(1+119,1+49*4) KEYL+Et+Ez
[econcn] = countrydata( output_cap, dpo, dcoef, cndata, tempdiff );


[iec_cn0, slopecn] = IEC_zone( cndata );

z8id=[2 2 2 3 4 5 6 1 1 7 8 1]; % 1 Globe; 2 Africa, 3 East Asia; 4 South/Southeast Asia; 5 Middle East; 6 Europe; 7 North America; 8 Oceania
xy_iec0=xy_iec;

% regression of regional temperature with global temperature
regress_tempzone=zeros(11,4); %1  N Ame; 2 S Ame; 3 W Eur; 4 N Afr & Middle East; 5 S Afr; 6 E Eur; 7 E Asia; 8 S & SE Asia; 9 Oceania; 10 Polar; 11 Ocean
tempinput = load('files\temperature.txt'); % 764x12 (1 globe; 2-11 region; 12 for ocean)
tempinputyy=zeros(63,12);
for yy=1:63
    tempinputyy(yy,1:12)=mean(tempinput((yy*12-11):(yy*12),1:12),1);
end
for regionid=1:11
    [b2,bint2,r2,rint2,stats2]=regress(tempinputyy(:,regionid+1),[ones(63,1) tempinputyy(:,1)]);
    regress_tempzone(regionid,1)=b2(2,1); % slope
    regress_tempzone(regionid,2)=(bint2(2,2)-bint2(2,1))/1.96/2; % std of slope
    regress_tempzone(regionid,3)=mean(tempinputyy(:,regionid+1),1); % ave of y
    regress_tempzone(regionid,4)=mean(tempinputyy(:,1),1); % ave of x
end

tempzone=zeros(11,2);
for regionid=1:11
    tempzone(regionid,1) = regress_tempzone(regionid,1); % slope of the varied curve
    tempzone(regionid,2) = regress_tempzone(regionid,3) - regress_tempzone(regionid,4) * tempzone(regionid,1); % intercept of the varied curve
end

% mc=1;
% for mc=1:(num3+nmc)
for mc=ss1:ss2
    
% if mod(mc,500)==1
    display(mc);
% end

pset=ones(1,num2);
if mc>num3
    % 1, generate a random value
    for j=1:num2
        pset(j) = min(2, max(0.1,randvar(unc(1:4,j),1,0)));
    end
else
    % 2, select the percentile i for parameter j
    i=mod(mc-1,num1) * 100 / (num1-1); % percentile
    j=floor((mc-1)/num1)+1; % parameter
    pset(j) = randvar(unc(1:4,j),2,i);
end
% pset=pset.*unc(1,:);
pset(16)=min(2,max(0,pset(16)));
pset(17)=min(2,max(0,pset(17)));


%Coefficient in the damage function
dcoef = dcoef0 * pset(1);
%Elasticity of substitution (avoid a zero-like elas)
elas = elas0 * max(0.04/elas0, pset(15));
%Learning rate on the cost curve
LR = LR0 * pset(18);

%Equilibrium sensitivity of climate
FFlux(1) = FFlux0(1) * pset(2);
%Time inertia of climate system to reach equilibirum (year)
FFlux(2) = FFlux0(2) * pset(3);
%air to land biosphere GtC/yr
FFlux(4) = FFlux0(4) * pset(6);
%air to surface ocean GtC/yr
FFlux(5) = FFlux0(5) * pset(7);
%land biosphere to soil GtC/yr
FFlux(6) = FFlux0(6) * pset(8);
%surface soil to deep soil GtC/yr
FFlux(7) = FFlux0(7) / pset(9);
%surface ocean to deep ocean GtC/yr
FFlux(8) = FFlux0(8) / pset(10);

%CO2 emission factors for fossil fuel only tCO2 / MJ
EFco2 = EFco20 * pset(4);
carbonbudget20(:,2) = carbonbudget20s(:,2) * pset(4);
%CO2 emissions from land use change
Eland = Eland0 * pset(5);
%Radiative forcing by 1 CH4, 2 N2O, 3 CFCs, 4 aerosol
for i=1:4
    Fex(:,i) = Fex0(:,i) * pset(i+10);
end

%Rates of induced efficiency changes
iec_cn=iec_cn0;
xy_iec=xy_iec0;
if climate_efficiency==1
    for cn=1:cn_num
        if cn==1
            z8=1;
        else
            z8=z8id(1,cou_iform(cndata(cn,1),3));
        end
        for i=1:71
            iec_cn(1,i,cn) = slopecn(z8,2) + (iec_cn(1,i,cn)-slopecn(z8,2)) * pset(16);
            iec_cn(2,i,cn) = slopecn(z8,5) + (iec_cn(2,i,cn)-slopecn(z8,5)) * pset(16);
            iec_cn(4,i,cn) = slopecn(z8,8) + (iec_cn(4,i,cn)-slopecn(z8,8)) * pset(17);
        end
    end
    for i=1:26
        xy_iec(i,6) = slopecn(1,2) + (xy_iec(i,6)-slopecn(1,2)) * pset(16);
        xy_iec(i,7) = slopecn(1,5) + (xy_iec(i,7)-slopecn(1,5)) * pset(16);
        xy_iec(i,8) = slopecn(1,8) + (xy_iec(i,8)-slopecn(1,8)) * pset(17);
    end
end

%Initial population (millions)
L0 = L(1,1);
%Initial level of total factor productivity
A0 = econo0(13) / (econo0(10)^alpha) / (L0/1000)^(1-alpha);
%Energy use efficiency $ / KJ
econo0(1) = econo0(15)^(elas/(elas-1)) / (econo0(12)/econo0(13));
%Energy production efficiency PJ / (trillion $)^0.3 / (billion cap)^0.7
econo0(2) = (A0^(elas-1) * econo0(15))^(1/(elas-1)) / econo0(1);
%Non-energy efficiency (trillion $)^0.7 / (billion cap)^0.7
econo0(3) = (A0^(elas-1) * (1-econo0(15)))^(1/(elas-1));
%Abatement cost as a percentage of GDP
econo0(5) = econo0(4) / theta2 * econo0(18)^theta2  * econo0(12) / econo0(13) * EFco2(1) / 1000;
%Industrial emissions (Gt CO2 per year)
econo0(20) = econo0(12) * EFco2(1,1) * (1-Egreen(1,8));

% switcher for  C1	C2	S1	S2	S3	S4	S5	T1	T2	T3	T4
switcher = ones(1,10);

%Calibration of climate damage function
% [output_dam] = Calibration_DAM( dcoef, dpo, xy_damage );
% save('..\output\output_dam.dat','output_dam');

%Calibration of equilibrium sensitivity of climate
% [output_esc] = Calibration_ESC( FFlux, 0 );

%Calibration of savings rate by capital, energy and ouput
[calrsav, output_cap] = Calibration_CAP( L, iec, dpo, dcoef, LR, switcher, 0 );

%Calibration of ENE reduction by COVID-19
[output_covid, deffs] = Calibration_COVID( FFlux, L, iec, calrsav, dpo, dcoef, LR, switcher, covidyear, 0 );

%Scenarios
if climate_efficiency==2
    switcher(2)=0; % deactivating the impact of climate change on efficieney of ENE
    switcher(4)=0; % deactivating the impact of climate change on efficieney of EUE
end

% region id
cc2=cndata(2:cn_num,1);
idx1=find(cou_iform(cc2,4)==1);
idx2=find(cou_iform(cc2,4)==2);
idx3=find(cou_iform(cc2,4)==3);
idx4=find(cou_iform(cc2,4)==4);

% BAU Scenario
abtcn=zeros(cn_num,3);
abtcn(:,1)=transtime;
abtcn(:,2)=1;
abtcn(:,3)=100;
S_Bau = Abatementzone( FFlux, L, dpo, dcoef, LR, covidyear, iec, iec_cn, calrsav, deffs, switcher, econcn, cndata, abtcn, tempzone, tempdiff, iecone, technology_diffusion, 2, 0 );
elasmu=1.45; % elasticity of marginal utility of consumption
disc=zeros(400,cn_num+5,50);
for cn=1:(cn_num+5)
    for j=121:400
        if cn<=(cn_num+1)
            pop=S_Bau(j,35,cn);
        elseif cn==(cn_num+2)
            pop=sum(S_Bau(j,35,idx1+2),3);
        elseif cn==(cn_num+3)
            pop=sum(S_Bau(j,35,idx2+2),3);
        elseif cn==(cn_num+4)
            pop=sum(S_Bau(j,35,idx3+2),3);
        elseif cn==(cn_num+5)
            pop=sum(S_Bau(j,35,idx4+2),3);
        end
        for r=1:50
            disc(j,cn,r)=((1-calrsav(5))*1000/pop)^(1-elasmu)/(1-elasmu)*pop/1000*(1-r*0.001)^(realtime(j,1)-2020);
        end
    end
end
output_gt=zeros(cn_num+1+5,14*3);
for cn=1:(cn_num+1)
    for s=1:14
        output_gt(cn,s)=log(S_Bau(121+s*5,7,cn)/S_Bau(111+s*5,7,cn))/10; % Growth rate in consumption in 2025, 2035, ..., 2080
        output_gt(cn,s+14)=(1-calrsav(5))*S_Bau(116+s*5,7,cn); % consumption in the year of mitigation in 2025, 2035, ..., 2080
        output_gt(cn,s+28)=S_Bau(116+s*5,35,cn); % population in 2025, 2035, ..., 2080
        if cn>=3
            zone4=cou_iform(cndata(cn-1,1),4); % 1 OCED/ 2 REF/ 3 ASIA/4 ALM
            output_gt(zone4+cn_num+1,s+14)=output_gt(zone4+cn_num+1,s+14)+output_gt(cn,s+14);
            output_gt(zone4+cn_num+1,s+28)=output_gt(zone4+cn_num+1,s+28)+output_gt(cn,s+28);
            output_gt(5+cn_num+1,s+14)=output_gt(5+cn_num+1,s+14)+output_gt(cn,s+14);
            output_gt(5+cn_num+1,s+28)=output_gt(5+cn_num+1,s+28)+output_gt(cn,s+28);
        end
    end
end
output_gt(1,1,1)=calrsav(5);

% scenarios of mitigation with cooperation
Nnet=31;
output_util=zeros(cn_num+5,5,Nnet,50);
output_temp=zeros(400,5,Nnet);
output_gdp=zeros(400,5,Nnet);
for NET=1:Nnet
%     display(NET);
    NETs=(NET-1)/10-1;
    abtcn(:,1)=transtime+30;
    abtcn(:,2)=1;
    abtcn(:,3)=translen;
    abtcn(1,1)=transtime;
    for coop=1:5
        if singles==2
            abtcn(2:cn_num,1)=transtime+30; % only one country/region mitigate early
        end
        for cn=1:(cn_num-1)
            if cou_iform(cndata(cn+1,1),4)==(coop-1)
                abtcn(cn+1,1)=transtime; % early action in order of 1 OCED 2 REF 3 ASIA 4 ALM
            end
        end
        S8 = Abatementzone( FFlux, L, dpo, dcoef, LR, covidyear, iec, iec_cn, calrsav, deffs, switcher, econcn, cndata, abtcn, tempzone, tempdiff, iecone, technology_diffusion, negative_emissions, NETs );        
        output_temp(1:400,coop,NET)=S8(1:400,31,1); % Atmospheric temperature, C
        output_gdp(1:400,coop,NET)=sum(S8(1:400,7,3:(cn_num+1)),3); % GDP, trillion $
        % 1 globe; 2 globe; 3-136 by country; 137-140 OCED/REF/ASIA/ALM; 141 World
        j=121; % 2025
        while realtime(j,1)<=2300
            for cn=1:(cn_num+5)
                if cn==2
                    Us = (sum(S8(j,7,3:(cn_num+1)),3))^(1-elasmu); % global utility
                elseif cn==(cn_num+2)
                    Us = (sum(S8(j,7,idx1+2),3))^(1-elasmu);
                elseif cn==(cn_num+3)
                    Us = (sum(S8(j,7,idx2+2),3))^(1-elasmu);
                elseif cn==(cn_num+4)
                    Us = (sum(S8(j,7,idx3+2),3))^(1-elasmu);
                elseif cn==(cn_num+5)
                    Us = (sum(S8(j,7,idx4+2),3))^(1-elasmu);
                else
                    Us = (S8(j,7,cn))^(1-elasmu); % utility by country
                end
                for r=1:50
                    Uscn = Us*disc(j,cn,r);
                    output_util(cn,coop,NET,r) = output_util(cn,coop,NET,r) + Uscn;  % NPV of utility
                end
            end
            j=j+1;
        end
    end
end

%Output parameters
parameters=zeros(56+71*3,1);
parameters(1,1) = dcoef;
parameters(2,1) = FFlux(1); % ESC
parameters(3,1) = FFlux(2); % Inertia time
parameters(4,1) = output_cap(45,20); % total emissions for 2015
parameters(5,1) = Eland(45,1); % total emissions for 2015
parameters(6:8,1) = FFlux(4:6);
parameters(9,1) = clim0(2)/FFlux(7);
parameters(10,1) = clim0(5)/FFlux(8);
parameters(11:14,1) = Fex(45,1:4);
parameters(15,1) =  elas;
parameters(16,1) = (xy_iec(1,6)-xy_iec(4,6))/(log(xy_iec(1,4))-log(xy_iec(4,4))); % (dEUE/EUE)/(dOmega/Omega)
parameters(17,1) = (xy_iec(1,8)-xy_iec(4,8))/(log(xy_iec(1,5))-log(xy_iec(4,5))); % (dENE/ENE)/(dOmega/Omega)
parameters(18,1) = LR;
parameters(19:23,1) = calrsav(1,1:5);
parameters(24:34,1) = deffs(1,1:11);
parameters(35:45,1) = deffs(2,1:11);
parameters(46:56,1) = deffs(3,1:11);
parameters(57:127,1) = iec(1,1:71); % EUE rate
parameters(128:198,1) = iec(2,1:71); % EPE rate
parameters(199:269,1) = iec(4,1:71); % ENE rate

% effs=1 or 2
save(strcat('..\coopeartion\monte198\effs=1\output_util_MC',num2str(mc),'.dat'),'output_util');
save(strcat('..\coopeartion\monte198\effs=1\output_temp_MC',num2str(mc),'.dat'),'output_temp');
save(strcat('..\coopeartion\monte198\effs=1\output_gdp_MC',num2str(mc),'.dat'),'output_gdp');
save(strcat('..\coopeartion\monte198\effs=1\output_gt_MC',num2str(mc),'.dat'),'output_gt');
save(strcat('..\coopeartion\monte198\effs=1\parameters_MC',num2str(mc),'.dat'),'parameters');

end

end







