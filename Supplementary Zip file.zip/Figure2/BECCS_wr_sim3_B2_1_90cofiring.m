% Author: Rong Wang
% Date: 2019.5.2

tic
clear;
mm=xlsread('decarbon_data.xlsx');% (1:bioenergy by electricity demand, unit: t biomass;2:bioenergy by carbon storage, unit: t biomass;3-15 bioenergy (indoor straw, infield straw, other use straw, resident fuelwood, residential ownusewood, commercial fuelwood, commercial bamboo, commercial roundwood, imported roudwood, imported sawnwood, imported wood pulp, dedicated crop in marginal land, dedicated crop in grassland (t biomass),county FID, province FID
nn=xlsread('monte.xlsx');% the uncertainty data of unit biomass transport cost (1-3 column is the min value, 4-6 column is the every 10% of the value added), unit CO2 transport cost (7-9 column is the min value, 10-12 column is the every 10% of the value added), unit biomass transport emission (13-15 column is the min value, 16-18 column is the every 10% of the value added) 
bioprice=[64.2 53.6 262.9 216.0 216.0];% bioenergy price($/t biomass,including biomass acquisition price, water price, preatment price, fertilizer price)of five biomass types (1 straw, 2 fuelwood, 3 other wood, 4 dedicated crop in marginal land, 5 dedicated crop in grassland.)
bioemis=[0.32 0.18 0.18 0.50 1.02];% unit CO2 emission from biomass treatment and fertilizer production, application, and landuse change (t CO2/t biomass) of five biomass types.
emis=[1.6 1.2 0.0005];%unit CO2 emission from carbon content in biomass, equivalent carbon emissions from coal, and retrofitting power plants (t CO2/t biomass)
% there are fixed variables
% there are 13 types of bioenergy, but according to their prices, we have
% only 5 types of bioenergy
elect=mm(:,1)*((9*19)/((9*19)+25)); % allowable bioenergy by electricity demand, unit: t biomass
cstore=mm(:,2); % allowable bioenergy by carbon storage, unit: t biomass
bioene=zeros(2836,5); % bioenergy resource, unit: t biomass
bioene(:,1)=sum(mm(:,3:5),2); % straw residuels
bioene(:,2)=sum(mm(:,6:8),2); % cheap wood
bioene(:,3)=sum(mm(:,9:13),2); % commercial wood
bioene(:,4:5)=mm(:,14:15); % dedicated energy crop
proid=mm(:,17)+1; % proince j for county i, j=1 to 34

for i=1:2836
    for j=1:5
        if bioene(i,j)==0
            bioene(i,j)=1e-50;
        end
    end
end

R_bioprice=zeros(1,5);
R_biotran=zeros(2836,3);
R_co2tran=zeros(2836,3);            
            
% this is the unit cost of bioenergy (k*y*x*i,1) for type of bioenergy 1-4
% destination of carbon 1-3, source of bioenergy 1-3, and county 1-2836
display('exclude zero x to reduce linear programming dimension');
nx=0;
for k=1:5 % bioenergy type
    for x=1:3 % biomass source
        for y=1:3 % storage sink
            for i=1:2836 % county
                % identify the zero variables to simply the linear programming dimension
                if elect(i)==0
                    continue; % no local power plants
                elseif cstore(i)==0 && y==1
                    continue; % no local storage
                elseif bioene(i,k)==0 && x==1
                    continue; % no local biomass
                end
                nx=nx+1;
            end
        end
    end
end
unitcost=zeros(nx,1); % in unit of $/t biomass

% equality constraints
Aeq=zeros(1,nx);
Aeq(1,1:nx)=emis(1,1)+emis(1,2)-emis(1,3);
Beq=zeros(1,1);
lb=zeros(nx,1);
ub=zeros(nx,1);

% inequality constrains by county, province and nation
nA=2836+2836+2836*5+34+5*34+1+5;
A=zeros(nA,nx);
B=zeros(nA,1);

display('define equality and inequality constraints');
n=0;
for k=1:5 % bioenergy type
    for x=1:3 % biomass source
        for y=1:3 % storage sink
            for i=1:2836 % county
                % identify the zero variables to simply the linear programming dimension
                if elect(i)==0
                    continue; % no local power plants
                elseif cstore(i)==0 && y==1
                    continue; % no local storage
                elseif bioene(i,k)==0 && x==1
                    continue; % no local biomass
                end
               %
                n=n+1;
                % unit function
                unitcost(n,1)=bioprice(1,k)+nn(i,x)+nn(i,(x+3))*5+nn(i,(y+6))+nn(i,(y+9))*5;
                
                % upper limit
                ub(n,1)=elect(i); % B in the nation
                
                % unit emission
                Aeq(1,n)=Aeq(1,n)-bioemis(1,k)-nn(i,x+12)-nn(i,(x+15))*5;
                
                % inequality constrains
                A(i,n)=1; % P in the county
                if y==1
                    A(i+2836,n)=1; % S in the county
                end
                if x==1
                    A(i+2836*(k+1),n)=1; % B in the county
                end
                if y<=2
                    A(2836*7+proid(i),n)=1;  % S in the province
                end
                if x<=2
                    A(2836*7+proid(i)+k*34,n)=1;  % B in the province
                end
                    A(2836*7+34*6+1,n)=1;  % S in the nation
                    A(2836*7+34*6+1+k,n)=1;  % B in the nation
            end
        end
    end
end
for i=1:2836
    B(i,1)=elect(i); % P in county
    B(i+2836,1)=cstore(i); % S in county
    B(2836*7+proid(i),1)=B(2836*7+proid(i),1)+cstore(i);  % S in province
    B(2836*7+34*6+1,1)=B(2836*7+34*6+1,1)+cstore(i);  % S in nation
    for k=1:5
        B(i+2836*(k+1),1)=bioene(i,k); % B in county
        B(2836*7+proid(i)+k*34,1)=B(2836*7+proid(i)+k*34,1)+bioene(i,k);  % B in province
        B(2836*7+34*6+1+k,1)=B(2836*7+34*6+1+k,1)+bioene(i,k);  % B in nation
    end
end

% remove some invalid inequality constrains
nB=0;
for i=1:nA
    if B(i,1)>0
        nB=nB+1;
    end
end
Anew=A(1:nB,:); Bnew=zeros(nB,1); n=0;
display('remove invalid inequality constrains');
for i=1:nA
    if B(i,1)>0
        n=n+1;
        for j=1:nx
            Anew(n,j)=A(i,j);
        end
        Bnew(n,1)=B(i,1);
    end
end
clear A B

% the optimizing target: optb(k*y*x*i,1) 
% optb(k*y*x*i,1) is the amount of kth type of bioenergy  for BEECS in county i, 
% from type k of bioenergy and x denotes the source of bioenergy 
% (x=1 for county i, 2 for other counties in the province, and 3 for other provinces) 
% and y denotes the destination of CO2.
% opt=zeros(4*3*3*2836,1);
% [opt, TC] = fmincon(@totalcost,x0,A,B,Aeq,Beq,lb,ub,[]);
            
fbeccs=0.0001;
Beq(1)=fbeccs; % mitigated CO2 emission (0 Gt).

display('start the linear programming');
% myoptions = optimset('Display','iter','FunValCheck','on','algorithm','sqp','MaxFunEvals',100000);
myoptions = optimset('Display','iter','MaxIter',100000);
u0=ub./45;
[optT, TC] = linprog(unitcost,Anew,Bnew,Aeq,Beq,lb,ub,u0,myoptions);
display('end the linear programming');

% the amount of bioenergy k used in power plants for BEECS in county i
% display('produce the bioenergy data');
biompower=zeros(2836,3,3,5); % in unit of $/t CO2
n=0;
for k=1:5
    for x=1:3
        for y=1:3
            for i=1:2836
                % identify the zero variables to simply the linear programming dimension
                if elect(i)==0
                    continue; % no local power plants
                elseif cstore(i)==0 && y==1
                    continue; % no local storage
                elseif bioene(i,k)==0 && x==1
                    continue; % no local biomass
                end
                n=n+1;
                biompower(i,y,x,k)=optT(n);
            end
        end
    end
end
save(strcat('result/PC_90','-',num2str(0),'.dat'),'biompower');

for fbeccs=1:60;
Beq(1)=fbeccs*1e8; % mitigated CO2 emission (from 0.1 Gt to 6 Gt).

display('start the linear programming');
% myoptions = optimset('Display','iter','FunValCheck','on','algorithm','sqp','MaxFunEvals',100000);
myoptions = optimset('Display','iter','MaxIter',100000);
u0=ub./45;
[optT, TC] = linprog(unitcost,Anew,Bnew,Aeq,Beq,lb,ub,u0,myoptions);
display('end the linear programming');

% the amount of bioenergy k used in power plants for BEECS in county i
% display('produce the bioenergy data');
biompower=zeros(2836,3,3,5); % in unit of $/t CO2
n=0;
for k=1:5
    for x=1:3
        for y=1:3
            for i=1:2836
                % identify the zero variables to simply the linear programming dimension
                if elect(i)==0
                    continue; % no local power plants
                elseif cstore(i)==0 && y==1
                    continue; % no local storage
                elseif bioene(i,k)==0 && x==1
                    continue; % no local biomass
                end
                n=n+1;
                biompower(i,y,x,k)=optT(n);% biomass amount (t biomass)
            end
        end
    end
end
save(strcat('result/PC_90','-',num2str(fbeccs),'.dat'),'biompower');
end

clear
toc


