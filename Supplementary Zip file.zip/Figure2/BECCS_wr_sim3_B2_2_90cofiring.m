% Author: Xiaofan Xing
% Date: 2019.11.23

tic
clear;
row=61;
F_reallyCO2=zeros(row,1);
TotalCO2=zeros(row,1);
F_co2=zeros(row,9);
F_cost=zeros(row,10);
F_price=zeros(row,10);
F_meancost=zeros(row,10);
Cost_biotran=zeros(row,10);

nn=xlsread('monte.xlsx');% the uncertainty data of unit biomass transport cost (1-3 column is the min value, 4-6 column is the every 10% of the value added), unit CO2 transport cost (7-9 column is the min value, 10-12 column is the every 10% of the value added), unit biomass transport emission (13-15 column is the min value, 16-18 column is the every 10% of the value added) 

bioprice=[31.0 31.0 240.3 131.6 131.6];% biomass acquisition price($/t biomass)
waterprice=[8.8	8.8	8.8 45.4 45.4];% water usage price in agricultural irrigation and power plant ($/t biomass)
treatprice=[15.3 13.8 13.8 19.8 19.8];% biomass pretreatment price($/t biomass)
ferprice=[9.1 0 0 19.2 19.2];% fertilizer usage price($/t biomass)
retrprice=[68.3 68.3 68.3 68.3 68.3];% retrofitting power plants price($/t biomass)
co2capprice=[91.4 91.4 91.4 91.4 91.4];% CO2 capture and storage price($/t biomass)
elecprice=[83.0 83.0 83.0 83.0 83.0];% Substituting coal price($/t biomass)
biotranprice=nn(:,1:3)+nn(:,4:6)*5; % Biomass transport price, ($/t biomass)
co2tranprice=nn(:,7:9)+nn(:,10:12)*5; % CO2 transport price, ($/t biomass)

caprate=[1.6 1.6 1.6 1.6 1.6];% unit CO2 captured from biomass (t CO2/t biomass)
coalrate=[1.2 1.2 1.2 1.2 1.2];% unit CO2 from substituted coal (t CO2/t biomass)
retrrate=[0.0005 0.0005 0.0005 0.0005 0.0005];% unit CO2 emission by retrofitting power plants in power plants (t CO2/t biomass)
treatrate=[0.2 0.18 0.18 0.24 0.24];% unit CO2 emission by biomass pretreatment (t CO2/t biomass)
pferrate=[0.08 0 0 0.18 0.18];% unit CO2 emission by fertilizers production (t CO2/t biomass)
aferrate=[0.04 0 0 0.08 0.08];% unit CO2 emission by fertilizers application (t CO2/t biomass)
biotranrate=nn(:,13:15)+nn(:,16:18)*5;% unit CO2 emission by biomass transport (t CO2/t biomass)
LUCrate=[0 0 0 0 0.52]; % unit CO2 emission by land use change (t CO2/t biomass)


for fbeccs=1:row
  for k=1:5 % bioenergy type
      for x=1:3 % biomass source
          for y=1:3 % storage sink
                 load(strcat('result/PC_90','-',num2str(fbeccs-1),'.dat'),'-mat');
                       biocost(:,y,x,k)=biompower(:,y,x,k).*repmat(bioprice(1,k),2836,1); % biomass acquisition cost ($)
                       watercost(:,y,x,k)=biompower(:,y,x,k).*repmat(waterprice(1,k),2836,1);% water usage cost in agricultural irrigation and power plant ($)
                       treatcost(:,y,x,k)=biompower(:,y,x,k).*repmat(treatprice(1,k),2836,1);% biomass pretreatment cost ($)
                       fercost(:,y,x,k)=biompower(:,y,x,k).*repmat(ferprice(1,k),2836,1);% fertilizer usage cost ($)
                       adjustcost(:,y,x,k)=biompower(:,y,x,k).*repmat(retrprice(1,k),2836,1);% retrofitting power plants cost ($)
                       co2capcost(:,y,x,k)=biompower(:,y,x,k).*repmat(co2capprice(1,k),2836,1);% CO2 capture and storage cost ($)
                       eleccost(:,y,x,k)=biompower(:,y,x,k).*repmat(elecprice(1,k),2836,1);% Substituting coal cost ($)
                       co2trancost(:,y,x,k)=biompower(:,y,x,k).*co2tranprice(:,y);% CO2 transport cost ($)
                       biotrancost(:,y,x,k)=biompower(:,y,x,k).*biotranprice(:,x);%Biomass transport cost ($)

                       capCO2(:,y,x,k)=biompower(:,y,x,k).*repmat(caprate(1,k),2836,1);% CO2 captured from biomass (t CO2)
                       coalCO2(:,y,x,k)=biompower(:,y,x,k).*repmat(coalrate(1,k),2836,1);% CO2 from substituted coal (t CO2)
                       adjustPCO2(:,y,x,k)=biompower(:,y,x,k).*repmat(retrrate(1,k),2836,1);% CO2 emission by retrofitting power plants in power plants (t CO2)
                       treatCO2(:,y,x,k)=biompower(:,y,x,k).*repmat(treatrate(1,k),2836,1);% CO2 emission by biomass pretreatment (t CO2)
                       pferCO2(:,y,x,k)=biompower(:,y,x,k).*repmat(pferrate(1,k),2836,1);% CO2 emission by fertilizers production (t CO2)
                       aferCO2(:,y,x,k)=biompower(:,y,x,k).*repmat(aferrate(1,k),2836,1);% CO2 emission by fertilizers application (t CO2)
                       biotranCO2(:,y,x,k)=biompower(:,y,x,k).*biotranrate(:,x);% CO2 emission by biomass transport (t CO2)
                       LUCCO2(:,y,x,k)=biompower(:,y,x,k).*repmat(LUCrate(1,k),2836,1);% CO2 emission by land use change (t CO2)
                       bio1(:,:,:)=biompower(:,:,:,1); % biomass amount of type 1
                       bio2(:,:,:)=biompower(:,:,:,2); % biomass amount of type 2
                       bio3(:,:,:)=biompower(:,:,:,3); % biomass amount of type 3
                       bio4(:,:,:)=biompower(:,:,:,4); % biomass amount of type 4
                       bio5(:,:,:)=biompower(:,:,:,5); % biomass amount of type 5
          end
      end
  end
Totalcost=sum(sum(sum(sum(biocost))))+sum(sum(sum(sum(treatcost))))+sum(sum(sum(sum(fercost))))+sum(sum(sum(sum(co2trancost))))+sum(sum(sum(sum(biotrancost))))+sum(sum(sum(sum(watercost))))+sum(sum(sum(sum(adjustcost))))+sum(sum(sum(sum(co2capcost))))-sum(sum(sum(sum(eleccost))));% total costs at each target emissions ($)
F_NetCO2(fbeccs,1)=sum(sum(sum(sum(capCO2))))+sum(sum(sum(sum(coalCO2))))-sum(sum(sum(sum(adjustPCO2))))-sum(sum(sum(sum(treatCO2))))-sum(sum(sum(sum(aferCO2))))-sum(sum(sum(sum(pferCO2))))-sum(sum(sum(sum(biotranCO2))))-sum(sum(sum(sum(LUCCO2))));% net emission at each target emissions (t CO2)
F_co2(fbeccs,:)=[F_NetCO2(fbeccs,1) sum(sum(sum(sum(adjustPCO2)))) sum(sum(sum(sum(biotranCO2)))) sum(sum(sum(sum(treatCO2)))) sum(sum(sum(sum(aferCO2)))) sum(sum(sum(sum(pferCO2)))) sum(sum(sum(sum(LUCCO2)))) sum(sum(sum(sum(coalCO2)))) sum(sum(sum(sum(capCO2))))];% the component of emission at each target emissions (t CO2)
F_cost(fbeccs,:)=[Totalcost sum(sum(sum(sum(watercost)))) sum(sum(sum(sum(fercost)))) sum(sum(sum(sum(co2trancost)))) sum(sum(sum(sum(co2capcost)))) sum(sum(sum(sum(biotrancost)))) sum(sum(sum(sum(treatcost)))) sum(sum(sum(sum(biocost)))) sum(sum(sum(sum(adjustcost)))) sum(sum(sum(sum(eleccost))))];% the component of cost at each target emissions ($)
Bio(fbeccs,:)=[sum(sum(sum(sum(biompower)))) sum(sum(sum(bio1))) sum(sum(sum(bio2))) sum(sum(sum(bio3))) sum(sum(sum(bio4))) sum(sum(sum(bio5)))];% the component of biomass at each target emissions (t biomass)
                    
 if fbeccs==1
  F_price(fbeccs,:)=F_cost(fbeccs,:)./F_NetCO2(fbeccs,1); % marginal cost ($/t CO2)
 elseif fbeccs>1
  F_price(fbeccs,:)=(F_cost(fbeccs,:)-F_cost((fbeccs-1),:))./(F_NetCO2(fbeccs,1)-F_NetCO2((fbeccs-1),1)); % marginal cost ($/t CO2)
 end
end

Picture=zeros(60,2);
for i=1:60
    if Bio(i,1)<=2.6765e9;% the restrictions of power planton biomass
       Picture(i,1)=F_NetCO2(i,1)/1e9;% CO2 emissions abated by BECCS (Gt CO2)
       Picture(i,2)=F_price(i,1);% Marginal cost of CO2 abatements by BECCS ($ (t CO2-eq)-1)
    elseif Bio(i,1)>2.6765e9;
       Picture(i,1)=nan;
       Picture(i,2)=nan;
    end
end

% Picture
x=Picture(:,1);
y=Picture(:,2);
plot(x,y,'-');
xlabel('CO2 emissions abated by BECCS (Gt CO2)'),ylabel('Marginal cost of CO2 abatements by BECCS ($ (t CO2-eq)-1)');
gtext('Co-firing in PC plants (90% biomass) to generate current electricity (4.24 PWh y-1)');
    
