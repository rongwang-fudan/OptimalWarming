tic;
clear;

mm=xlsread('BECCSdata.xlsx');% cost(trillion y-1), net emission (T y-1), and electricity (PWh y-1) of BECCS.  
nn=xlsread('electricity.xlsx');% total, coal, nuclear, water, wind, and solar electricity generation (PWh -1),and gdp (trillion $ y-1) from 2011 to 2018.
qq=xlsread('rate_FYPwwsngdpelec.xlsx');%increase ratio (%) of total, nuclear, water, wind, solar electricty generation, and gdp from 2011 to 2030.
yr=20; % reasearch year from 2011 to 2030.
cc=121; % x label (WWSN share (31%-58%) or BECCS cost (0-3% of GDP))
Ra_De_elec=qq(1,:); % electricity demand growing ratio (% y-1)
Ra_nuclear=qq(2,:);% nuclear energy growing ratio (% y-1).
Ra_water=qq(3,:);% water energy growing ratio (% y-1).
Ra_wind=qq(4,:);% wind energy growing ratio (% y-1).
Ra_solar=qq(5,:);% solar energy growing ratio (% y-1).
Ra_gdp=qq(6,:);% gdp growing ratio (% y-1).
De_elec=zeros(1,yr); % total electricity demand (PWh)
Co_elec=zeros(cc,yr);% coal electricity demand with no expansion of WWSN since 2021(PWh)
Co_elec_wwsn=zeros(cc,yr);% coal electricity demand with growing WWSN over 2021-2030 in the FYP(PWh)
Co_elec_wwsn_beccs=zeros(cc,yr);% coal electricity demand with growing WWSN over 2021-2030, and further increasing investement in BECCS since 2021(PWh)
Nu_elec=zeros(1,yr); % nuclear energy in yr year(PWh).
Wa_elec=zeros(1,yr);% water energy in yr year(PWh).
Wi_elec=zeros(1,yr);% wind energy in yr year(PWh).
So_elec=zeros(1,yr);% solar energy in yr year(PWh).
gdp=zeros(1,yr);% gdp in yr year(PWh).
S_NDC=zeros(1,yr);% the carbon emission in NDC scenarios (Gt y-1).

for i=1:8
De_elec(1,i)=nn(1,i);% electricity demand from 2011 to 2018 (PWh y-1)
Co_elec(1:cc,i)=nn(2,i);% electricity generation by coal plant from 2011 to 2018 (PWh y-1)
Co_elec_wwsn(1:cc,i)=nn(2,i);% electricity generation by coal plant from 2011 to 2018 (PWh y-1)
Nu_elec(1,i)=nn(3,i);% electricity generation by nuclear plant from 2011 to 2018 (PWh y-1)
Wa_elec(1,i)=nn(4,i);% electricity generation by water plant from 2011 to 2018 (PWh y-1)
Wi_elec(1,i)=nn(5,i);% electricity generation by wind plant from 2011 to 2018 (PWh y-1)
So_elec(1,i)=nn(6,i);% electricity generation by solar plant from 2011 to 2018 (PWh y-1)
gdp(1,i)=nn(7,i);% gdp from 2011 to 2018 (trillion $ y-1)
end

for i=9:20
De_elec(1,i)=De_elec(1,i-1)*(1+Ra_De_elec(1,i));% electricity demand from 2019 to 2030 (PWh y-1)
Nu_elec(1,i)=Nu_elec(1,i-1)*(1+Ra_nuclear(1,i));% electricity generation by nuclear plant from 2019 to 2030 (PWh y-1)
Wa_elec(1,i)=Wa_elec(1,i-1)*(1+Ra_water(1,i));% electricity generation by water plant from 2019 to 2030 (PWh y-1)
Wi_elec(1,i)=Wi_elec(1,i-1)*(1+Ra_wind(1,i));% electricity generation by wind plant from 2019 to 2030 (PWh y-1)
So_elec(1,i)=So_elec(1,i-1)*(1+Ra_solar(1,i));% electricity generation by solar plant from 2019 to 2030 (PWh y-1)
gdp(1,i)=gdp(1,i-1)*(1+Ra_gdp(1,i));% gdp from 2019 to 2030 (trillion $ y-1)
Co_elec(1:cc,i)=De_elec(1,i)-Nu_elec(1,11)-Wa_elec(1,11)-Wi_elec(1,11)-So_elec(1,11);% electricity generation by coal plant (no expansion of WWSN since 2020) from 2019 to 2030 (PWh y-1)
Co_elec_wwsn(1:cc,i)=De_elec(1,i)-Nu_elec(1,i)-Wa_elec(1,i)-Wi_elec(1,i)-So_elec(1,i);% electricity generation by coal plant (expansion of WWSN since 2020) from 2019 to 2030 (PWh y-1)
end

figure(1);
subplot(1,1,1);
%Figure1
Figure1=[Nu_elec;So_elec;Wi_elec;Wa_elec;Co_elec_wwsn(1,:)];% the cumulative power generation by nuclear, solar, wind, water, coal or beccs energy (PWh y-1).
x=[2011:1:2030];% x axis from 2011 to 2030.
area(x',Figure1');
ylim([0 14]); % y axis from 1 to 14 PWh.
xlabel('Year'),ylabel('Capacity of coal and other renewable power plants without BECCS (PWh y-1)');
legend('Nuclear','Solar','Wind','water','coal or beccs','location','northwest');
